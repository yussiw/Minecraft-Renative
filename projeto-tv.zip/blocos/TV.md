# Blocos TV — controles

Versão para TV Box (Android 7.1+, OpenGL ES 2.0, Mali-450). O mundo 3D é desenhado em 960x540 e esticado para a tela.

## Controle remoto (só setas + OK)
- Setas ↑ ↓: andar para frente / trás
- Setas ← →: girar a câmera
- OK (toque curto): colocar / usar · OK (segurar): quebrar bloco
- MENU: liga/desliga o **cursor virtual** (setas movem o cursor, OK clica nos botões da tela: pular, agachar, hotbar...)
- Nos menus e no inventário o cursor está sempre ligado
- Teclas coloridas: vermelho = pular, verde = agachar, amarelo = usar, azul / INFO = inventário
- CH+ / CH- (ou PAGE UP / PAGE DOWN): trocar slot · BACK: pausa / voltar

## Gamepad
- Analógico esquerdo: andar · analógico direito: olhar
- A pular · B agachar · X usar · Y inventário
- RT quebrar · LT usar · RB / LB trocar slot · L3 correr · R3 câmera (F5)
- START: pausa · SELECT: cursor virtual
- Direcional ← →: trocar slot

## Teclado / mouse USB
- W A S D, Espaço, Shift, Ctrl, E, Q, 1–9, Esc, F1–F5; mouse funciona como toque; roda do mouse troca o slot
