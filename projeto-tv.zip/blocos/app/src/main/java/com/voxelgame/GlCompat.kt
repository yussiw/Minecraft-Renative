package com.voxelgame

import android.opengl.GLES20
import java.nio.Buffer

/**
 * Camada de compatibilidade OpenGL ES 2.0 (TV Box com GPU Mali-450).
 *
 * O resto do codigo chama "GLES30.glAlgumaCoisa"; aqui "GLES30" e um objeto proprio que repassa tudo para
 * o GLES20 e emula os VAOs (que nao existem no ES 2.0) guardando a configuracao dos atributos e
 * reaplicando-a em cada glBindVertexArray.
 */
object GLES30 {
    const val GL_TEXTURE_2D = GLES20.GL_TEXTURE_2D
    const val GL_ARRAY_BUFFER = GLES20.GL_ARRAY_BUFFER
    const val GL_ELEMENT_ARRAY_BUFFER = GLES20.GL_ELEMENT_ARRAY_BUFFER
    const val GL_FLOAT = GLES20.GL_FLOAT
    const val GL_CULL_FACE = GLES20.GL_CULL_FACE
    const val GL_BLEND = GLES20.GL_BLEND
    const val GL_DEPTH_TEST = GLES20.GL_DEPTH_TEST
    const val GL_STATIC_DRAW = GLES20.GL_STATIC_DRAW
    const val GL_DYNAMIC_DRAW = GLES20.GL_DYNAMIC_DRAW
    const val GL_NEAREST = GLES20.GL_NEAREST
    const val GL_LINEAR = GLES20.GL_LINEAR
    const val GL_NEAREST_MIPMAP_NEAREST = GLES20.GL_NEAREST_MIPMAP_NEAREST
    const val GL_LINEAR_MIPMAP_LINEAR = GLES20.GL_LINEAR_MIPMAP_LINEAR
    const val GL_CLAMP_TO_EDGE = GLES20.GL_CLAMP_TO_EDGE
    const val GL_REPEAT = GLES20.GL_REPEAT
    const val GL_TEXTURE_MIN_FILTER = GLES20.GL_TEXTURE_MIN_FILTER
    const val GL_TEXTURE_MAG_FILTER = GLES20.GL_TEXTURE_MAG_FILTER
    const val GL_TEXTURE_WRAP_S = GLES20.GL_TEXTURE_WRAP_S
    const val GL_TEXTURE_WRAP_T = GLES20.GL_TEXTURE_WRAP_T
    const val GL_TEXTURE0 = GLES20.GL_TEXTURE0
    const val GL_TEXTURE1 = GLES20.GL_TEXTURE1
    const val GL_RGBA = GLES20.GL_RGBA
    const val GL_RGBA32F = 0x8814 // so existe no ES 3.0; so e usado pelo modelo .glb, desligado na TV
    const val GL_UNSIGNED_BYTE = GLES20.GL_UNSIGNED_BYTE
    const val GL_UNSIGNED_SHORT = GLES20.GL_UNSIGNED_SHORT
    const val GL_UNSIGNED_INT = GLES20.GL_UNSIGNED_INT
    const val GL_TRIANGLES = GLES20.GL_TRIANGLES
    const val GL_LINES = GLES20.GL_LINES
    const val GL_SRC_ALPHA = GLES20.GL_SRC_ALPHA
    const val GL_ONE_MINUS_SRC_ALPHA = GLES20.GL_ONE_MINUS_SRC_ALPHA
    const val GL_SRC_COLOR = GLES20.GL_SRC_COLOR
    const val GL_DST_COLOR = GLES20.GL_DST_COLOR
    const val GL_VERTEX_SHADER = GLES20.GL_VERTEX_SHADER
    const val GL_FRAGMENT_SHADER = GLES20.GL_FRAGMENT_SHADER
    const val GL_LINK_STATUS = GLES20.GL_LINK_STATUS
    const val GL_COMPILE_STATUS = GLES20.GL_COMPILE_STATUS
    const val GL_DEPTH_BUFFER_BIT = GLES20.GL_DEPTH_BUFFER_BIT
    const val GL_COLOR_BUFFER_BIT = GLES20.GL_COLOR_BUFFER_BIT

    /** true: este build roda em OpenGL ES 2.0 (sem modelo .glb animado). */
    const val ES2 = true

    // ------------------------------------------------------------ VAO emulado

    private const val MAXA = 8

    private class Va {
        val en = BooleanArray(MAXA)
        val buf = IntArray(MAXA)
        val size = IntArray(MAXA)
        val type = IntArray(MAXA)
        val norm = BooleanArray(MAXA)
        val stride = IntArray(MAXA)
        val off = IntArray(MAXA)
        var ibo = 0
    }

    private val vaos = HashMap<Int, Va>()
    private var nextVao = 1
    private var cur: Va? = null
    private var arrayBuf = 0

    /** Chamar quando o contexto GL e recriado: os handles antigos nao valem mais. */
    fun reset() {
        vaos.clear()
        nextVao = 1
        cur = null
        arrayBuf = 0
    }

    fun glGenVertexArrays(n: Int, ids: IntArray, offset: Int) {
        for (i in 0 until n) {
            val id = nextVao++
            vaos[id] = Va()
            ids[offset + i] = id
        }
    }

    fun glDeleteVertexArrays(n: Int, ids: IntArray, offset: Int) {
        for (i in 0 until n) {
            val v = vaos.remove(ids[offset + i])
            if (v != null && v === cur) cur = null
        }
    }

    fun glBindVertexArray(id: Int) {
        val va = if (id == 0) null else vaos[id]
        cur = va
        if (va == null) {
            for (i in 0 until MAXA) GLES20.glDisableVertexAttribArray(i)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
            return
        }
        for (i in 0 until MAXA) {
            if (va.en[i]) {
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, va.buf[i])
                GLES20.glVertexAttribPointer(i, va.size[i], va.type[i], va.norm[i], va.stride[i], va.off[i])
                GLES20.glEnableVertexAttribArray(i)
            } else {
                GLES20.glDisableVertexAttribArray(i)
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, arrayBuf)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, va.ibo)
    }

    fun glBindBuffer(target: Int, buffer: Int) {
        if (target == GLES20.GL_ARRAY_BUFFER) arrayBuf = buffer
        else if (target == GLES20.GL_ELEMENT_ARRAY_BUFFER) cur?.ibo = buffer
        GLES20.glBindBuffer(target, buffer)
    }

    fun glEnableVertexAttribArray(index: Int) {
        val v = cur
        if (v != null && index in 0 until MAXA) v.en[index] = true
        GLES20.glEnableVertexAttribArray(index)
    }

    fun glDisableVertexAttribArray(index: Int) {
        val v = cur
        if (v != null && index in 0 until MAXA) v.en[index] = false
        GLES20.glDisableVertexAttribArray(index)
    }

    fun glVertexAttribPointer(index: Int, size: Int, type: Int, normalized: Boolean, stride: Int, offset: Int) {
        val v = cur
        if (v != null && index in 0 until MAXA) {
            v.buf[index] = arrayBuf
            v.size[index] = size
            v.type[index] = type
            v.norm[index] = normalized
            v.stride[index] = stride
            v.off[index] = offset
        }
        GLES20.glVertexAttribPointer(index, size, type, normalized, stride, offset)
    }

    /** No ES 2.0 nao ha atributos inteiros: os bytes chegam ao shader como float (0..255). */
    fun glVertexAttribIPointer(index: Int, size: Int, type: Int, stride: Int, offset: Int) {
        glVertexAttribPointer(index, size, type, false, stride, offset)
    }

    // ------------------------------------------------------------ repasse direto

    fun glBindAttribLocation(program: Int, index: Int, name: String) = GLES20.glBindAttribLocation(program, index, name)
    fun glGetUniformLocation(program: Int, name: String): Int = GLES20.glGetUniformLocation(program, name)

    fun glGenBuffers(n: Int, buffers: IntArray, offset: Int) = GLES20.glGenBuffers(n, buffers, offset)
    fun glDeleteBuffers(n: Int, buffers: IntArray, offset: Int) = GLES20.glDeleteBuffers(n, buffers, offset)
    fun glBufferData(target: Int, size: Int, data: Buffer?, usage: Int) = GLES20.glBufferData(target, size, data, usage)

    fun glGenTextures(n: Int, textures: IntArray, offset: Int) = GLES20.glGenTextures(n, textures, offset)
    fun glDeleteTextures(n: Int, textures: IntArray, offset: Int) = GLES20.glDeleteTextures(n, textures, offset)
    fun glBindTexture(target: Int, texture: Int) = GLES20.glBindTexture(target, texture)
    fun glActiveTexture(texture: Int) = GLES20.glActiveTexture(texture)
    fun glTexParameteri(target: Int, pname: Int, param: Int) = GLES20.glTexParameteri(target, pname, param)
    fun glGenerateMipmap(target: Int) = GLES20.glGenerateMipmap(target)
    fun glTexImage2D(
        target: Int, level: Int, internalformat: Int, width: Int, height: Int,
        border: Int, format: Int, type: Int, pixels: Buffer?
    ) = GLES20.glTexImage2D(target, level, internalformat, width, height, border, format, type, pixels)
    fun glTexSubImage2D(
        target: Int, level: Int, xoffset: Int, yoffset: Int, width: Int, height: Int,
        format: Int, type: Int, pixels: Buffer?
    ) = GLES20.glTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels)
    fun glReadPixels(x: Int, y: Int, width: Int, height: Int, format: Int, type: Int, pixels: Buffer?) =
        GLES20.glReadPixels(x, y, width, height, format, type, pixels)

    fun glCreateShader(type: Int): Int = GLES20.glCreateShader(type)
    fun glShaderSource(shader: Int, source: String) = GLES20.glShaderSource(shader, source)
    fun glCompileShader(shader: Int) = GLES20.glCompileShader(shader)
    fun glGetShaderiv(shader: Int, pname: Int, params: IntArray, offset: Int) = GLES20.glGetShaderiv(shader, pname, params, offset)
    fun glGetShaderInfoLog(shader: Int): String = GLES20.glGetShaderInfoLog(shader)
    fun glCreateProgram(): Int = GLES20.glCreateProgram()
    fun glAttachShader(program: Int, shader: Int) = GLES20.glAttachShader(program, shader)
    fun glLinkProgram(program: Int) = GLES20.glLinkProgram(program)
    fun glGetProgramiv(program: Int, pname: Int, params: IntArray, offset: Int) = GLES20.glGetProgramiv(program, pname, params, offset)
    fun glGetProgramInfoLog(program: Int): String = GLES20.glGetProgramInfoLog(program)
    fun glUseProgram(program: Int) = GLES20.glUseProgram(program)
    fun glDeleteProgram(program: Int) = GLES20.glDeleteProgram(program)

    fun glUniform1i(location: Int, x: Int) = GLES20.glUniform1i(location, x)
    fun glUniform1f(location: Int, x: Float) = GLES20.glUniform1f(location, x)
    fun glUniform2f(location: Int, x: Float, y: Float) = GLES20.glUniform2f(location, x, y)
    fun glUniform3f(location: Int, x: Float, y: Float, z: Float) = GLES20.glUniform3f(location, x, y, z)
    fun glUniform4f(location: Int, x: Float, y: Float, z: Float, w: Float) = GLES20.glUniform4f(location, x, y, z, w)
    fun glUniformMatrix4fv(location: Int, count: Int, transpose: Boolean, value: FloatArray, offset: Int) =
        GLES20.glUniformMatrix4fv(location, count, transpose, value, offset)

    fun glEnable(cap: Int) = GLES20.glEnable(cap)
    fun glDisable(cap: Int) = GLES20.glDisable(cap)
    fun glDepthMask(flag: Boolean) = GLES20.glDepthMask(flag)
    fun glBlendFunc(sfactor: Int, dfactor: Int) = GLES20.glBlendFunc(sfactor, dfactor)
    fun glClearColor(r: Float, g: Float, b: Float, a: Float) = GLES20.glClearColor(r, g, b, a)
    fun glClear(mask: Int) = GLES20.glClear(mask)
    fun glViewport(x: Int, y: Int, w: Int, h: Int) = GLES20.glViewport(x, y, w, h)

    fun glDrawArrays(mode: Int, first: Int, count: Int) = GLES20.glDrawArrays(mode, first, count)
    fun glDrawElements(mode: Int, count: Int, type: Int, offset: Int) = GLES20.glDrawElements(mode, count, type, offset)
}
