# Mods JAVL

O Blocos agora inclui a primeira versão do runtime próprio de mods `.javl`.

1. Abra uma partida e entre no menu de pausa.
2. Escolha **Mods .javl...**.
3. Toque em **IMPORTAR MOD .JAVL** e selecione um pacote.
4. Volte à partida. O mod é carregado no processo do jogo; alguns hooks de menu podem aparecer ao reabrir a pausa.

Formato, manifesto e API: `docs/mods/JAVL_FORMAT.md`.
Exemplo instalável: `examples/hello_world.javl`.

Esta versão inicial executa Lua, registra eventos, adiciona botões ao menu de pausa, consulta/altera alguns dados do jogo, mescla texturas PNG no atlas, toca sons OGG/WAV/MP3 e permite ler JSON/texto. Modelos 3D e uma API completa para desenhar telas arbitrárias ficam para as próximas etapas. A sandbox ainda não tem limite de instruções/tempo; instale somente mods confiáveis.
