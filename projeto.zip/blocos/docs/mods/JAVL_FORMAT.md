# Formato de mods JAVL (API 1)

Um arquivo `.javl` é um ZIP comum renomeado. O manifesto fica na raiz e o script principal padrão é `scripts/main.lua`.

## Estrutura mínima

```text
meu_mod.javl
├── manifest.json
├── scripts/
│   └── main.lua
├── textures/
├── sounds/
├── models/
├── ui/
└── config.json
```

Pastas de assets são opcionais. JSON e outros arquivos de texto podem ser lidos por `mods.asset_text(path)`. PNGs no caminho de resource pack `assets/minecraft/textures/` entram no atlas do jogo; o resource pack base é mesclado primeiro e mods são aplicados em ordem alfabética de ID (o último sobrescreve arquivos com o mesmo caminho). Sons OGG, WAV e MP3 podem ser tocados por `mods.play_sound(path, volume)`. Modelos ainda ficam apenas empacotados: o pipeline de modelos será implementado depois.

## manifest.json

```json
{
  "id": "meu_mod",
  "name": "Meu primeiro mod",
  "version": "1.0.0",
  "api_version": 1,
  "entry": "scripts/main.lua"
}
```

`id` aceita de 1 a 48 caracteres: letras, números, `_`, `-` e `.`. `name` e `version` são obrigatórios. `api_version` padrão é 1. `entry` pode apontar para outro `.lua` dentro do ZIP, sem caminhos absolutos ou `..`.

## API Lua disponível

```lua
mods.log("Mod carregado")

mods.on("game_start", function()
    mods.log("A partida começou")
end)

mods.on("tick", function(delta)
    -- chamado a cada atualização do jogo, inclusive enquanto pausado
end)

mods.on("pause_menu_open", function()
    mods.log("Menu de pausa aberto")
end)

mods.add_pause_button("Meu botão", function()
    game.set_time(0.25)
end)

local texto = mods.asset_text("config.json")
mods.play_sound("sounds/hello.ogg", 0.8)

local x, y, z = game.get_player_position()
game.set_player_position(x, y, z)
game.set_time(0.5)
local hora = game.get_time()
game.set_creative(true)
local criativo = game.is_creative()
local vida = game.get_health()
game.set_health(20)
local fome = game.get_food()
game.set_food(20)
local bloco = game.get_block(0, 64, 0)
game.set_block(0, 64, 0, 3) -- coloca pedra
```

### Eventos

- `game_start`: depois que os mods são carregados no início da sessão.
- `tick(delta)`: a cada atualização do jogo.
- `pause_menu_open`: quando o menu de pausa abre.
- `game_stop`: ao encerrar a sessão da engine.

### Funções `game`

- `get_time()` / `set_time(0..1)` — horário do ciclo de dia.
- `is_creative()` / `set_creative(boolean)` — modo criativo.
- `get_player_position()` — retorna `x, y, z`.
- `set_player_position(x, y, z)` — teletransporta o jogador.
- `get_health()` / `set_health(0..20)` — vida.
- `get_food()` / `set_food(0..20)` — fome.
- `get_block(x, y, z)` / `set_block(x, y, z, block_id)` — consulta e altera blocos (`0` remove; `1..16` IDs atuais).

### Funções `mods`

- `log(text)` — escreve no Logcat.
- `on(event, function)` — registra callback.
- `add_pause_button(label, function)` — adiciona botão ao menu de pausa (máximo de 8 por mod (a HUD inicial exibe até 3 no menu de pausa)).
- `asset_text(path)` — lê um arquivo de texto dentro do pacote; retorna `nil` se não existir.
- `play_sound(path, volume)` — toca um arquivo `.ogg`, `.wav` ou `.mp3` do pacote; volume de 0 a 1.
- `get_version()` — versão da API como texto.

## Segurança e limites atuais

O runtime remove as bibliotecas Lua de acesso a arquivos, sistema operacional, depuração, carregamento de módulos e ponte Java (`io`, `os`, `debug`, `package`, `luajava`, `require`, `dofile`, `loadfile`, `load` e `loadstring`). O importador limita o arquivo compactado a 32 MB, cada entrada a 8 MB e o conteúdo descompactado declarado a 64 MB, além de rejeitar caminhos perigosos.

Isto é uma primeira camada de isolamento, não uma sandbox endurecida para mods não confiáveis: ainda não há limite de instruções/tempo de execução nem permissões granulares. Instale apenas mods de fontes confiáveis até essas proteções serem adicionadas.

## Assets suportados na API 1

- **Texturas:** PNG no caminho `assets/minecraft/textures/`, usando nomes/caminhos compatíveis com o atlas atual do Blocos. Os mods são mesclados com o resource pack selecionado.
- **Sons:** OGG, WAV ou MP3 em qualquer caminho interno, tocados via `mods.play_sound`.
- **JSON/configurações:** texto lido via `mods.asset_text`.
- **Modelos:** ainda não são carregados pelo renderer.

## Compatibilidade

- Blocos: versão inicial 0.4-javl.
- JAVL API: 1.
- Linguagem: Lua via LuaJ 3.0.1.
- Os mods `.javl` são exclusivos do Blocos e não executam mods `.jar` do Minecraft Java.
