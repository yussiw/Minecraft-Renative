mods.log("Hello World carregado no Blocos!")

mods.on("game_start", function()
    mods.log("Bem-vindo ao mundo")
end)

mods.on("tick", function(delta)
    -- Exemplo: a cada tick o mod pode consultar e alterar o estado do jogo.
end)

mods.add_pause_button("Meio-dia", function()
    game.set_time(0.25)
    mods.log("Horário alterado para meio-dia")
end)
