package com.voxelgame

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Tela simples para importar e administrar pacotes .javl. */
class ModsActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(0xFF171717.toInt())
        }
        val title = TextView(this).apply {
            text = "MODS JAVL"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Mods próprios do Blocos • Lua • API 1\nImporte arquivos .javl para adicionar scripts e conteúdo."
            textSize = 13f
            setTextColor(0xFFBBBBBB.toInt())
            setPadding(0, 8, 0, 14)
        }
        root.addView(subtitle)
        root.addView(Button(this).apply { text = "IMPORTAR MOD .JAVL"; setOnClickListener { pickMod() } })
        root.addView(Button(this).apply { text = "ATUALIZAR LISTA"; setOnClickListener { refresh() } })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "VOLTAR"; setOnClickListener { finish() } })
        setContentView(root)
        refresh()
    }

    private fun pickMod() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQ_MOD)
    }

    @Deprecated("Activity result API mantida compatível com o restante do projeto")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MOD || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val message = try {
                contentResolver.openInputStream(uri)!!.use { ModRuntime.install(this, it) }
            } catch (t: Throwable) { "Falha ao importar .javl: ${t.message ?: "arquivo inválido"}" }
            runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); refresh() }
        }.start()
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val mods = ModRuntime.list(this)
        if (mods.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nenhum mod instalado.\n\nUm .javl é um ZIP com manifest.json e scripts/main.lua."
                textSize = 15f; setTextColor(0xFFDDDDDD.toInt()); setPadding(8, 18, 8, 18)
            })
        }
        mods.forEach { mod ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 10, 12, 10)
                setBackgroundColor(0xFF292929.toInt())
            }
            val label = if (mod.enabled) "ATIVO" else "NÃO CARREGOU"
            card.addView(TextView(this).apply {
                text = "${mod.name}  [$label]\nID: ${mod.id}  •  versão ${mod.version}" + (mod.error?.let { "\nErro: $it" } ?: "")
                textSize = 14f; setTextColor(if (mod.enabled) 0xFF9BE59B.toInt() else 0xFFFFA0A0.toInt())
            })
            card.addView(Button(this).apply {
                text = "REMOVER"
                setOnClickListener {
                    try { ModRuntime.remove(this@ModsActivity, mod.id); refresh() }
                    catch (t: Throwable) { Toast.makeText(this@ModsActivity, t.message, Toast.LENGTH_SHORT).show() }
                }
            })
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 10
            list.addView(card, lp)
        }
    }

    companion object { private const val REQ_MOD = 91 }
}
