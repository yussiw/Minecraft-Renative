package com.voxelgame

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Controles de toque e HUD desenhados por cima do GLSurfaceView. */
class HudView(ctx: Context, private val input: Input) : View(ctx) {
    private val dp = resources.displayMetrics.density
    private val sens = 0.0085f / dp
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val icon = Paint().apply { isFilterBitmap = false }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * dp
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val src = Rect()
    private val dst = RectF()

    private var slot = 44f * dp
    private var hbX = 0f
    private var hbY = 0f
    private var jx = 0f
    private var jy = 0f
    private val jr = 38f * dp
    private val joyR = 56f * dp
    private val slop = 12f * dp
    private val holdMs = 380L

    private var joyId = -1
    private var joyOx = 0f
    private var joyOy = 0f
    private var joyKx = 0f
    private var joyKy = 0f
    private var lookId = -1
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var lookMoved = false
    private var lookFired = false
    private var lookDownAt = 0L
    private var jumpId = -1

    private val longPress = Runnable {
        if (lookId != -1 && !lookMoved) {
            input.placeReq = true
            lookFired = true
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        slot = min(46f * dp, w / 11f)
        hbX = (w - 8 * slot) / 2f
        hbY = h - slot - 8f * dp
        jx = w - 84f * dp
        jy = h - 96f * dp
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                onDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) onMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(e.getPointerId(e.actionIndex), true)
            MotionEvent.ACTION_CANCEL -> {
                onUp(joyId, false)
                onUp(lookId, false)
                onUp(jumpId, false)
            }
        }
        invalidate()
        return true
    }

    private fun onDown(id: Int, x: Float, y: Float) {
        // hotbar
        if (y >= hbY && y <= hbY + slot && x >= hbX && x <= hbX + 8 * slot) {
            input.selected = ((x - hbX) / slot).toInt().coerceIn(0, 7)
            return
        }
        // pulo
        if (jumpId == -1 && hypot(x - jx, y - jy) <= jr * 1.25f) {
            jumpId = id
            input.jump = true
            return
        }
        // joystick (metade esquerda)
        if (joyId == -1 && x < width * 0.45f) {
            joyId = id
            joyOx = x; joyOy = y
            joyKx = 0f; joyKy = 0f
            return
        }
        // olhar / quebrar / colocar
        if (lookId == -1) {
            lookId = id
            lastX = x; lastY = y
            startX = x; startY = y
            lookMoved = false
            lookFired = false
            lookDownAt = System.currentTimeMillis()
            postDelayed(longPress, holdMs)
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id == joyId) {
            var dx = x - joyOx
            var dy = y - joyOy
            val d = hypot(dx, dy)
            if (d > joyR) { dx = dx / d * joyR; dy = dy / d * joyR }
            joyKx = dx; joyKy = dy
            input.moveX = dx / joyR
            input.moveY = -dy / joyR
        } else if (id == lookId) {
            if (!lookMoved && hypot(x - startX, y - startY) > slop) {
                lookMoved = true
                removeCallbacks(longPress)
            }
            if (lookMoved) input.addLook((x - lastX) * sens, (y - lastY) * sens)
            lastX = x; lastY = y
        }
    }

    private fun onUp(id: Int, normal: Boolean) {
        if (id == -1) return
        if (id == joyId) {
            joyId = -1
            joyKx = 0f; joyKy = 0f
            input.moveX = 0f
            input.moveY = 0f
        } else if (id == lookId) {
            removeCallbacks(longPress)
            if (normal && !lookMoved && !lookFired && System.currentTimeMillis() - lookDownAt < holdMs) {
                input.breakReq = true
            }
            lookId = -1
        } else if (id == jumpId) {
            jumpId = -1
            input.jump = false
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        c.drawText("${Stats.fps.toInt()} FPS  |  dist ${Stats.radius}  |  ${Stats.chunks} chunks", 12f * dp, 22f * dp, text)

        // mira
        fill.style = Paint.Style.STROKE
        fill.strokeWidth = 2f * dp
        fill.color = Color.argb(200, 255, 255, 255)
        val cx = w / 2f
        val cy = h / 2f
        c.drawLine(cx - 9f * dp, cy, cx + 9f * dp, cy, fill)
        c.drawLine(cx, cy - 9f * dp, cx, cy + 9f * dp, fill)

        // hotbar
        for (i in 0 until 8) {
            val l = hbX + i * slot
            dst.set(l + 3f * dp, hbY + 3f * dp, l + slot - 3f * dp, hbY + slot - 3f * dp)
            fill.style = Paint.Style.FILL
            fill.color = Color.argb(110, 0, 0, 0)
            c.drawRect(l, hbY, l + slot, hbY + slot, fill)
            val t = Blocks.iconTile[Blocks.hotbar[i]]
            val tx = (t % Atlas.TILES) * Atlas.TS
            val ty = (t / Atlas.TILES) * Atlas.TS
            src.set(tx, ty, tx + Atlas.TS, ty + Atlas.TS)
            c.drawBitmap(Atlas.bitmap, src, dst, icon)
            if (i == input.selected) {
                fill.style = Paint.Style.STROKE
                fill.strokeWidth = 3f * dp
                fill.color = Color.WHITE
                c.drawRect(l, hbY, l + slot, hbY + slot, fill)
            }
        }

        // joystick
        val bx = if (joyId != -1) joyOx else 110f * dp
        val by = if (joyId != -1) joyOy else h - 110f * dp
        fill.style = Paint.Style.FILL
        fill.color = Color.argb(if (joyId != -1) 70 else 35, 255, 255, 255)
        c.drawCircle(bx, by, joyR, fill)
        fill.color = Color.argb(if (joyId != -1) 150 else 70, 255, 255, 255)
        c.drawCircle(bx + joyKx, by + joyKy, 24f * dp, fill)

        // botao de pulo
        fill.color = Color.argb(if (jumpId != -1) 130 else 70, 255, 255, 255)
        c.drawCircle(jx, jy, jr, fill)
        fill.style = Paint.Style.STROKE
        fill.strokeWidth = 3f * dp
        fill.color = Color.argb(200, 255, 255, 255)
        c.drawLine(jx - 12f * dp, jy + 6f * dp, jx, jy - 8f * dp, fill)
        c.drawLine(jx, jy - 8f * dp, jx + 12f * dp, jy + 6f * dp, fill)

        postInvalidateDelayed(250)
    }
}
