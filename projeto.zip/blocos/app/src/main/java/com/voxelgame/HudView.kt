package com.voxelgame

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Controles de toque e HUD desenhados por cima do GLSurfaceView. */
class HudView(ctx: Context, private val input: Input, private val onPickPack: () -> Unit) : View(ctx) {
    private val packRect = RectF()
    private val flyRect = RectF()
    private val invRect = RectF()
    private val panel = RectF()
    private val dp = resources.displayMetrics.density
    private val sens = 0.0085f / dp
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val icon = Paint().apply { isFilterBitmap = false }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * dp
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }
    private val src = Rect()
    private val dst = RectF()

    private var slot = 44f * dp
    private var hbX = 0f
    private var hbY = 0f
    private var jx = 0f
    private var jy = 0f
    private var downX = 0f
    private var downY = 0f
    private val downR = 28f * dp
    private val jr = 38f * dp
    private val joyR = 56f * dp
    private val slop = 12f * dp
    private val holdMs = 380L

    private val cols = 6
    private var cell = 0f
    private var invX = 0f
    private var invY = 0f
    private var invOpen = false

    private var joyId = -1
    private var joyOx = 0f
    private var joyOy = 0f
    private var joyKx = 0f
    private var joyKy = 0f
    private var lookId = -1
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var lookMoved = false
    private var lookFired = false
    private var lookDownAt = 0L
    private var jumpId = -1
    private var downId = -1

    private val longPress = Runnable {
        if (lookId != -1 && !lookMoved) {
            input.breakReq = true
            lookFired = true
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        slot = min(46f * dp, w / 11f)
        hbX = (w - 8 * slot) / 2f
        hbY = h - slot - 8f * dp
        jx = w - 84f * dp
        jy = h - 96f * dp
        downX = jx - 82f * dp
        downY = jy + 20f * dp

        val bw = 62f * dp
        val bh = 34f * dp
        val gap = 8f * dp
        packRect.set(w - 12f * dp - bw, 10f * dp, w - 12f * dp, 10f * dp + bh)
        flyRect.set(packRect.left - gap - bw, 10f * dp, packRect.left - gap, 10f * dp + bh)
        invRect.set(flyRect.left - gap - bw, 10f * dp, flyRect.left - gap, 10f * dp + bh)

        cell = min(54f * dp, (h - 80f * dp) / 2.6f)
        invX = (w - cols * cell) / 2f
        invY = (h - 2 * cell) / 2f + 10f * dp
        panel.set(invX - 12f * dp, invY - 34f * dp, invX + cols * cell + 12f * dp, invY + 2 * cell + 12f * dp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                onDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) onMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> onUp(e.getPointerId(e.actionIndex), true)
            MotionEvent.ACTION_CANCEL -> {
                onUp(joyId, false)
                onUp(lookId, false)
                onUp(jumpId, false)
                onUp(downId, false)
            }
        }
        invalidate()
        return true
    }

    private fun onDown(id: Int, x: Float, y: Float) {
        // botoes do topo
        if (packRect.contains(x, y)) {
            onPickPack()
            return
        }
        if (flyRect.contains(x, y)) {
            input.flyToggle = true
            return
        }
        if (invRect.contains(x, y)) {
            invOpen = !invOpen
            return
        }
        // hotbar
        if (y >= hbY && y <= hbY + slot && x >= hbX && x <= hbX + 8 * slot) {
            input.selected = ((x - hbX) / slot).toInt().coerceIn(0, 7)
            return
        }
        // inventario aberto: captura o toque
        if (invOpen) {
            if (x >= invX && y >= invY) {
                val ix = ((x - invX) / cell).toInt()
                val iy = ((y - invY) / cell).toInt()
                if (ix in 0 until cols && iy in 0 until 2) {
                    val idx = iy * cols + ix
                    if (idx < Blocks.placeable.size) {
                        input.hotbar[input.selected.coerceIn(0, 7)] = Blocks.placeable[idx]
                        invOpen = false
                    }
                    return
                }
            }
            if (!panel.contains(x, y)) invOpen = false
            return
        }
        // descer (so voando)
        if (Stats.flying && downId == -1 && hypot(x - downX, y - downY) <= downR * 1.3f) {
            downId = id
            input.down = true
            return
        }
        // pulo / subir
        if (jumpId == -1 && hypot(x - jx, y - jy) <= jr * 1.25f) {
            jumpId = id
            input.jump = true
            return
        }
        // joystick (metade esquerda)
        if (joyId == -1 && x < width * 0.45f) {
            joyId = id
            joyOx = x; joyOy = y
            joyKx = 0f; joyKy = 0f
            return
        }
        // olhar / quebrar / colocar
        if (lookId == -1) {
            lookId = id
            lastX = x; lastY = y
            startX = x; startY = y
            lookMoved = false
            lookFired = false
            lookDownAt = System.currentTimeMillis()
            postDelayed(longPress, holdMs)
        }
    }

    private fun onMove(id: Int, x: Float, y: Float) {
        if (id == joyId) {
            var dx = x - joyOx
            var dy = y - joyOy
            val d = hypot(dx, dy)
            if (d > joyR) { dx = dx / d * joyR; dy = dy / d * joyR }
            joyKx = dx; joyKy = dy
            input.moveX = dx / joyR
            input.moveY = -dy / joyR
        } else if (id == lookId) {
            if (!lookMoved && hypot(x - startX, y - startY) > slop) {
                lookMoved = true
                removeCallbacks(longPress)
            }
            if (lookMoved) input.addLook((x - lastX) * sens, (y - lastY) * sens)
            lastX = x; lastY = y
        }
    }

    private fun onUp(id: Int, normal: Boolean) {
        if (id == -1) return
        if (id == joyId) {
            joyId = -1
            joyKx = 0f; joyKy = 0f
            input.moveX = 0f
            input.moveY = 0f
        } else if (id == lookId) {
            removeCallbacks(longPress)
            if (normal && !lookMoved && !lookFired && System.currentTimeMillis() - lookDownAt < holdMs) {
                input.placeReq = true
            }
            lookId = -1
        } else if (id == jumpId) {
            jumpId = -1
            input.jump = false
        } else if (id == downId) {
            downId = -1
            input.down = false
        }
    }

    private fun button(c: Canvas, r: RectF, label: String, on: Boolean) {
        fill.style = Paint.Style.FILL
        fill.color = if (on) Color.argb(170, 70, 160, 70) else Color.argb(110, 0, 0, 0)
        c.drawRoundRect(r, 8f * dp, 8f * dp, fill)
        c.drawText(label, r.left + (r.width() - text.measureText(label)) / 2f, r.top + 22f * dp, text)
    }

    private fun drawIcon(c: Canvas, atlas: android.graphics.Bitmap, id: Int, l: Float, t: Float, r: Float, b: Float) {
        val ats = atlas.width / Atlas.TILES
        val tile = Blocks.iconTile[id]
        val tx = (tile % Atlas.TILES) * ats
        val ty = (tile / Atlas.TILES) * ats
        src.set(tx, ty, tx + ats, ty + ats)
        dst.set(l, t, r, b)
        c.drawBitmap(atlas, src, dst, icon)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        // debaixo d'agua
        if (Stats.underwater) {
            fill.style = Paint.Style.FILL
            fill.color = Color.argb(85, 10, 50, 150)
            c.drawRect(0f, 0f, w, h, fill)
        }

        c.drawText("${Stats.fps.toInt()} FPS  |  dist ${Stats.radius}  |  ${Stats.chunks} chunks", 12f * dp, 22f * dp, text)
        c.drawText("XYZ ${Stats.x} ${Stats.y} ${Stats.z}  |  ${Stats.clock}", 12f * dp, 40f * dp, text)

        // mira
        fill.style = Paint.Style.STROKE
        fill.strokeWidth = 2f * dp
        fill.color = Color.argb(200, 255, 255, 255)
        val cx = w / 2f
        val cy = h / 2f
        c.drawLine(cx - 9f * dp, cy, cx + 9f * dp, cy, fill)
        c.drawLine(cx, cy - 9f * dp, cx, cy + 9f * dp, fill)

        // botoes do topo
        button(c, invRect, "Blocos", invOpen)
        button(c, flyRect, "Voar", Stats.flying)
        button(c, packRect, "Pack", false)

        // hotbar
        val atlas = Atlas.bitmap
        for (i in 0 until 8) {
            val l = hbX + i * slot
            fill.style = Paint.Style.FILL
            fill.color = Color.argb(110, 0, 0, 0)
            c.drawRect(l, hbY, l + slot, hbY + slot, fill)
            drawIcon(c, atlas, input.hotbar[i], l + 3f * dp, hbY + 3f * dp, l + slot - 3f * dp, hbY + slot - 3f * dp)
            if (i == input.selected) {
                fill.style = Paint.Style.STROKE
                fill.strokeWidth = 3f * dp
                fill.color = Color.WHITE
                c.drawRect(l, hbY, l + slot, hbY + slot, fill)
            }
        }
        val nm = Blocks.names[input.hotbar[input.selected.coerceIn(0, 7)]]
        c.drawText(nm, (w - text.measureText(nm)) / 2f, hbY - 8f * dp, text)

        // inventario
        if (invOpen) {
            fill.style = Paint.Style.FILL
            fill.color = Color.argb(215, 25, 25, 25)
            c.drawRoundRect(panel, 10f * dp, 10f * dp, fill)
            c.drawText("Escolha o bloco do slot ${input.selected + 1}", panel.left + 12f * dp, panel.top + 24f * dp, text)
            val current = input.hotbar[input.selected.coerceIn(0, 7)]
            for (i in Blocks.placeable.indices) {
                val l = invX + (i % cols) * cell
                val tp = invY + (i / cols) * cell
                val id = Blocks.placeable[i]
                fill.style = Paint.Style.FILL
                fill.color = Color.argb(70, 255, 255, 255)
                c.drawRect(l + 2f * dp, tp + 2f * dp, l + cell - 2f * dp, tp + cell - 2f * dp, fill)
                drawIcon(c, atlas, id, l + 7f * dp, tp + 7f * dp, l + cell - 7f * dp, tp + cell - 7f * dp)
                if (id == current) {
                    fill.style = Paint.Style.STROKE
                    fill.strokeWidth = 3f * dp
                    fill.color = Color.WHITE
                    c.drawRect(l + 2f * dp, tp + 2f * dp, l + cell - 2f * dp, tp + cell - 2f * dp, fill)
                }
            }
        }

        // joystick
        val bx = if (joyId != -1) joyOx else 110f * dp
        val by = if (joyId != -1) joyOy else h - 110f * dp
        fill.style = Paint.Style.FILL
        fill.color = Color.argb(if (joyId != -1) 70 else 35, 255, 255, 255)
        c.drawCircle(bx, by, joyR, fill)
        fill.color = Color.argb(if (joyId != -1) 150 else 70, 255, 255, 255)
        c.drawCircle(bx + joyKx, by + joyKy, 24f * dp, fill)

        // botao de pulo (sobe, quando voando)
        fill.color = Color.argb(if (jumpId != -1) 130 else 70, 255, 255, 255)
        c.drawCircle(jx, jy, jr, fill)
        fill.style = Paint.Style.STROKE
        fill.strokeWidth = 3f * dp
        fill.color = Color.argb(200, 255, 255, 255)
        c.drawLine(jx - 12f * dp, jy + 6f * dp, jx, jy - 8f * dp, fill)
        c.drawLine(jx, jy - 8f * dp, jx + 12f * dp, jy + 6f * dp, fill)

        // botao de descer (so voando)
        if (Stats.flying) {
            fill.style = Paint.Style.FILL
            fill.color = Color.argb(if (downId != -1) 130 else 70, 255, 255, 255)
            c.drawCircle(downX, downY, downR, fill)
            fill.style = Paint.Style.STROKE
            fill.strokeWidth = 3f * dp
            fill.color = Color.argb(200, 255, 255, 255)
            c.drawLine(downX - 10f * dp, downY - 5f * dp, downX, downY + 7f * dp, fill)
            c.drawLine(downX, downY + 7f * dp, downX + 10f * dp, downY - 5f * dp, fill)
        }

        postInvalidateDelayed(250)
    }
}
