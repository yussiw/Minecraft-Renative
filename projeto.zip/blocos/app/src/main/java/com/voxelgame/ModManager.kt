package com.voxelgame

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * Mods (.jar ou .zip). Dois tipos de conteudo, que podem estar no mesmo arquivo:
 *
 * 1) Assets de mods Java (Forge/NeoForge/Fabric/Quilt): blockstates + modelos de cubo, modelos de item
 *    "generated/handheld", lang pt_br/en_us e receitas data/<ns>/recipes (formato vanilla).
 * 2) JSON de comportamento desta API (data/<ns>/blocks, data/<ns>/items):
 *      blocks/<nome>.json: name, texture | textures{top,side,bottom}, hardness, light(0-15), damage(HP/s),
 *                          tool, drop ("none" | "ns:item"), drop_count, on_use{give,count,heal,feed,message,
 *                          consume,replace,cooldown}, worldgen{min_y,max_y,tries,vein}
 *      items/<nome>.json:  name, texture, food{hunger,saturation}, heal, tool{type,speed,attack}
 *
 * O codigo Java (.class) dos mods NAO e executado.
 */
object ModManager {
    class ModInfo(
        val label: String, var blocks: Int, var items: Int, var recipes: Int,
        var skipped: Int, val hasCode: Boolean
    )

    @Volatile var loaded: List<ModInfo> = emptyList()
        private set

    fun dir(filesDir: File) = File(filesDir, "mods")

    private class Cand(
        val key: String, val name: String, val top: String?, val side: String?, val bottom: String?,
        val def: BlockDef?, val wg: JSONObject?
    )

    private class ItemCand(val key: String, val name: String, val tex: String?, val j: JSONObject?)

    @Synchronized
    fun loadAll(filesDir: File) {
        Atlas.clearMods()
        Blocks.resetMods()
        Recipes.reset()
        val regFile = File(filesDir, "mods_ids.json")
        val reg = HashMap<String, Int>()
        try {
            if (regFile.exists()) {
                val j = JSONObject(regFile.readText())
                val it = j.keys()
                while (it.hasNext()) { val k = it.next(); reg[k] = j.getInt(k) }
            }
        } catch (t: Throwable) { reg.clear() }

        fun alloc(key: String, lo: Int, hi: Int): Int? {
            val old = reg[key]
            if (old != null && old in lo..hi) return old
            val free = (lo..hi).firstOrNull { x -> !reg.containsValue(x) }
            if (free != null) reg[key] = free
            return free
        }

        val files = dir(filesDir).listFiles { f -> f.isFile && (f.name.endsWith(".jar") || f.name.endsWith(".zip")) }
            ?.sortedBy { it.name } ?: emptyList()
        val infos = ArrayList<ModInfo>()
        val blockIds = ArrayList<Int>()
        val itemIds = ArrayList<Int>()
        val ores = ArrayList<Ore>()

        // passo 1: blocos e itens
        for (f in files) {
            try {
                ZipFile(f).use { zf ->
                    val r = Reader(zf)
                    var skipped = r.skipped
                    var nb = 0
                    var ni = 0
                    for (c in r.blocks()) {
                        val id = alloc(c.key, Blocks.MOD_FIRST, Blocks.MOD_LAST)
                        if (id == null) { skipped++; continue }
                        val tTop = tile(zf, r, c.top ?: c.side)
                        val tSide = tile(zf, r, c.side ?: c.top)
                        val tBot = tile(zf, r, c.bottom ?: c.top ?: c.side)
                        if (tTop < 0 || tSide < 0 || tBot < 0) { skipped++; continue }
                        Blocks.registerMod(id, c.name, tTop, tSide, tBot)
                        Blocks.keyToId[c.key.lowercase()] = id
                        val d = c.def
                        if (d != null) Blocks.registerDef(id, c.key, d)
                        val wg = c.wg
                        if (wg != null) {
                            ores.add(Ore(
                                id, wg.optInt("min_y", 4).coerceIn(1, H - 2), wg.optInt("max_y", 48).coerceIn(2, H - 1),
                                wg.optInt("tries", 4).coerceIn(1, 40), wg.optInt("vein", 4).coerceIn(1, 16)
                            ))
                        }
                        blockIds.add(id)
                        nb++
                    }
                    for (ic in r.items()) {
                        val id = alloc("item:" + ic.key, Blocks.ITEM_FIRST, Blocks.ITEM_LAST)
                        val tl = tile(zf, r, ic.tex)
                        if (id == null || tl < 0) { skipped++; continue }
                        val j = ic.j
                        val food = j?.optJSONObject("food")
                        val tool = j?.optJSONObject("tool")
                        Blocks.registerItem(ItemDef(
                            id, ic.key, ic.name, tl,
                            food?.optInt("hunger", 0) ?: 0,
                            food?.optDouble("saturation", 0.0)?.toFloat() ?: 0f,
                            j?.optDouble("heal", 0.0)?.toFloat() ?: 0f,
                            tool?.optString("type")?.ifEmpty { null },
                            tool?.optDouble("speed", 1.0)?.toFloat() ?: 1f,
                            tool?.optDouble("attack", 1.0)?.toFloat() ?: 1f
                        ))
                        itemIds.add(id)
                        ni++
                    }
                    infos.add(ModInfo(r.label(f.name), nb, ni, 0, skipped, r.hasCode))
                }
            } catch (t: Throwable) {
                infos.add(ModInfo(f.name + " (invalido)", 0, 0, 0, 0, false))
            }
        }

        Blocks.ores = ores
        Blocks.finishMods(blockIds, itemIds)

        // passo 2: receitas (precisam de todos os ids ja registrados)
        for ((i, f) in files.withIndex()) {
            try {
                ZipFile(f).use { zf ->
                    val res = Reader(zf).addRecipes()
                    infos[i].recipes += res.first
                    infos[i].skipped += res.second
                }
            } catch (t: Throwable) { }
        }

        try {
            val j = JSONObject()
            for ((k, v) in reg) j.put(k, v)
            regFile.writeText(j.toString())
        } catch (t: Throwable) { }
        loaded = infos
    }

    fun clear(filesDir: File) {
        dir(filesDir).listFiles()?.forEach { it.delete() }
    }

    /** "ns:caminho" -> tile do atlas (le o PNG do proprio jar; o pack pode trocar depois). */
    private fun tile(zf: ZipFile, r: Reader, ref: String?): Int {
        if (ref == null) return -1
        val ns = ref.substringBefore(':')
        val path = ref.substringAfter(':')
        val e = r.entry("assets/$ns/textures/$path.png")
        val tex = if (e != null) try { zf.getInputStream(e).use { Atlas.decodeTex(it) } } catch (t: Throwable) { null } else null
        return Atlas.allocModTile("$ns:$path".lowercase(), tex)
    }

    // ---------------------------------------------------------------- leitura do arquivo

    private class Reader(val zf: ZipFile) {
        private val entries = HashMap<String, ZipEntry>()
        private val langs = HashMap<String, JSONObject?>()
        var hasCode = false
        var skipped = 0

        init {
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                val n = e.name.replace('\\', '/')
                if (n.endsWith(".class")) hasCode = true
                entries[n.lowercase()] = e
            }
        }

        fun entry(path: String): ZipEntry? = entries[path.lowercase()]

        fun json(path: String): JSONObject? {
            val e = entry(path) ?: return null
            return try { JSONObject(zf.getInputStream(e).use { String(it.readBytes(), Charsets.UTF_8) }) } catch (t: Throwable) { null }
        }

        fun label(fallback: String): String {
            json("fabric.mod.json")?.optString("name")?.takeIf { it.isNotBlank() }?.let { return it }
            json("quilt.mod.json")?.optJSONObject("quilt_loader")?.optJSONObject("metadata")?.optString("name")
                ?.takeIf { it.isNotBlank() }?.let { return it }
            json("mod.json")?.optString("name")?.takeIf { it.isNotBlank() }?.let { return it }
            for (tomlPath in arrayOf("META-INF/mods.toml", "META-INF/neoforge.mods.toml")) {
                val e = entry(tomlPath) ?: continue
                val txt = try { zf.getInputStream(e).use { String(it.readBytes(), Charsets.UTF_8) } } catch (t: Throwable) { "" }
                Regex("displayName\\s*=\\s*\"([^\"]+)\"").find(txt)?.let { return it.groupValues[1] }
            }
            return fallback.removeSuffix(".jar").removeSuffix(".zip")
        }

        private fun lang(ns: String): JSONObject? = langs.getOrPut(ns) {
            json("assets/$ns/lang/pt_br.json") ?: json("assets/$ns/lang/en_us.json")
        }

        private fun pretty(name: String): String =
            name.substringAfterLast('/').split('_').joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }

        private fun shown(kind: String, ns: String, name: String): String =
            lang(ns)?.optString("$kind.$ns.${name.replace('/', '.')}")?.takeIf { it.isNotBlank() } ?: pretty(name)

        /** Referencia de textura: sem namespace = o do proprio mod (nos JSON desta API). */
        private fun ref(ns: String, v: String): String = if (v.contains(':')) v.lowercase() else "$ns:$v".lowercase()

        private fun key(ns: String, v: String): String =
            if (v.isEmpty() || v == "none" || v.contains(':')) v.lowercase() else "$ns:$v".lowercase()

        private fun parseUse(ns: String, o: JSONObject): UseAction = UseAction(
            give = o.optString("give").ifEmpty { null }?.let { key(ns, it) },
            giveCount = o.optInt("count", 1).coerceIn(1, 64),
            heal = o.optDouble("heal", 0.0).toFloat(),
            feed = o.optInt("feed", 0),
            message = o.optString("message").ifEmpty { null },
            consume = o.optBoolean("consume", false),
            replace = o.optString("replace").ifEmpty { null }?.let { key(ns, it) },
            cooldown = o.optDouble("cooldown", 0.5).toFloat()
        )

        private fun parseDef(ns: String, j: JSONObject): BlockDef = BlockDef(
            hardness = j.optDouble("hardness", 1.0).toFloat(),
            light = j.optInt("light", 0).coerceIn(0, 15),
            damage = j.optDouble("damage", 0.0).toFloat(),
            tool = j.optString("tool").ifEmpty { null },
            dropKey = if (j.has("drop")) key(ns, j.optString("drop")) else null,
            dropCount = j.optInt("drop_count", 1).coerceIn(0, 64),
            use = j.optJSONObject("on_use")?.let { parseUse(ns, it) }
        )

        // ------------------------------------------------------------ blocos

        fun blocks(): List<Cand> {
            val out = ArrayList<Cand>()
            val data = HashMap<String, JSONObject>()
            val dre = Regex("^data/([^/]+)/blocks/(.+)\\.json$")
            for (m in entries.keys.mapNotNull { dre.find(it) }) {
                val j = json(m.value) ?: continue
                data[m.groupValues[1] + ":" + m.groupValues[2]] = j
            }

            val re = Regex("^assets/([^/]+)/blockstates/(.+)\\.json$")
            val states = entries.keys.mapNotNull { re.find(it) }.sortedBy { it.value }
            val done = HashSet<String>()
            for (m in states) {
                val ns = m.groupValues[1]
                val name = m.groupValues[2]
                if (ns == "minecraft") continue
                val k = "$ns:$name"
                val bs = json(m.value) ?: continue
                val model = firstModel(bs)
                val faces = if (model != null) resolve(ns, model) else null
                if (faces == null) { skipped++; continue }
                val dj = data[k]
                val nm = dj?.optString("name")?.takeIf { it.isNotBlank() } ?: shown("block", ns, name)
                out.add(Cand(k, nm, faces[0], faces[1], faces[2], dj?.let { parseDef(ns, it) }, dj?.optJSONObject("worldgen")))
                done.add(k)
            }

            // blocos definidos so por JSON (sem blockstate): textura vem do proprio JSON
            for (k in data.keys.sorted()) {
                if (k in done) continue
                val j = data[k]!!
                val ns = k.substringBefore(':')
                val name = k.substringAfter(':')
                val tj = j.optJSONObject("textures")
                val all = j.optString("texture").ifEmpty { null }?.let { ref(ns, it) }
                val top = tj?.optString("top")?.ifEmpty { null }?.let { ref(ns, it) } ?: all
                val side = tj?.optString("side")?.ifEmpty { null }?.let { ref(ns, it) } ?: all ?: top
                val bottom = tj?.optString("bottom")?.ifEmpty { null }?.let { ref(ns, it) } ?: all ?: top
                if (top == null && side == null) { skipped++; continue }
                val nm = j.optString("name").ifEmpty { shown("block", ns, name) }
                out.add(Cand(k, nm, top ?: side, side ?: top, bottom ?: top ?: side, parseDef(ns, j), j.optJSONObject("worldgen")))
            }
            return out.sortedBy { it.key }
        }

        // ------------------------------------------------------------ itens

        fun items(): List<ItemCand> {
            val out = ArrayList<ItemCand>()
            val seen = HashSet<String>()
            val dre = Regex("^data/([^/]+)/items/(.+)\\.json$")
            for (m in entries.keys.mapNotNull { dre.find(it) }.sortedBy { it.value }) {
                val ns = m.groupValues[1]
                val name = m.groupValues[2]
                val j = json(m.value) ?: continue
                val nm = j.optString("name").ifEmpty { shown("item", ns, name) }
                val tx = j.optString("texture").ifEmpty { "item/$name" }
                out.add(ItemCand("$ns:$name".lowercase(), nm, ref(ns, tx), j))
                seen.add("$ns:$name".lowercase())
            }
            // itens "generated/handheld" dos mods Java (materiais, sem comportamento)
            val mre = Regex("^assets/([^/]+)/models/item/(.+)\\.json$")
            for (m in entries.keys.mapNotNull { mre.find(it) }.sortedBy { it.value }) {
                val ns = m.groupValues[1]
                val name = m.groupValues[2]
                val k = "$ns:$name".lowercase()
                if (ns == "minecraft" || k in seen) continue
                if (entries.containsKey("assets/$ns/blockstates/$name.json")) continue // item de bloco
                val mj = json(m.value) ?: continue
                val parent = mj.optString("parent")
                if (!parent.contains("generated") && !parent.contains("handheld")) continue
                val l0 = mj.optJSONObject("textures")?.optString("layer0")?.ifEmpty { null } ?: continue
                val full = if (l0.contains(':')) l0.lowercase() else "minecraft:$l0"
                out.add(ItemCand(k, shown("item", ns, name), full, null))
            }
            return out
        }

        // ------------------------------------------------------------ receitas

        private fun one(s: String): IntArray? {
            if (s.startsWith("#")) return Recipes.tag(s)
            val id = Blocks.idOf(s)
            return if (id > 0) intArrayOf(id) else null
        }

        private fun ingredient(o: Any?): IntArray? = when (o) {
            is String -> one(o)
            is JSONObject -> o.optString("item").ifEmpty { null }?.let { one(it) }
                ?: o.optString("tag").ifEmpty { null }?.let { Recipes.tag(it) }
            is JSONArray -> {
                val ids = ArrayList<Int>()
                for (i in 0 until o.length()) ingredient(o.opt(i))?.forEach { ids.add(it) }
                if (ids.isEmpty()) null else ids.toIntArray()
            }
            else -> null
        }

        private fun result(o: Any?): Pair<Int, Int>? = when (o) {
            is String -> Blocks.idOf(o).takeIf { it > 0 }?.let { Pair(it, 1) }
            is JSONObject -> {
                val s = o.optString("item").ifEmpty { o.optString("id") }
                Blocks.idOf(s).takeIf { it > 0 }?.let { Pair(it, o.optInt("count", 1).coerceIn(1, 64)) }
            }
            else -> null
        }

        /** Devolve (receitas adicionadas, ignoradas). */
        fun addRecipes(): Pair<Int, Int> {
            var ok = 0
            var bad = 0
            val re = Regex("^data/([^/]+)/recipes?/(.+)\\.json$")
            for (m in entries.keys.mapNotNull { re.find(it) }.sortedBy { it.value }) {
                val j = json(m.value) ?: continue
                val type = j.optString("type").removePrefix("minecraft:")
                if (type != "crafting_shaped" && type != "crafting_shapeless") continue
                val res = result(j.opt("result"))
                if (res == null) { bad++; continue }
                if (type == "crafting_shaped") {
                    val pat = j.optJSONArray("pattern")
                    val keyObj = j.optJSONObject("key")
                    if (pat == null || keyObj == null || pat.length() == 0 || pat.length() > 3) { bad++; continue }
                    val rows = (0 until pat.length()).map { pat.optString(it) }
                    val w = rows.maxOf { it.length }
                    val h = rows.size
                    if (w == 0 || w > 3) { bad++; continue }
                    val grid = arrayOfNulls<IntArray>(w * h)
                    var good = true
                    for (y in 0 until h) for (x in 0 until w) {
                        val ch = if (x < rows[y].length) rows[y][x] else ' '
                        if (ch == ' ') continue
                        val ing = ingredient(keyObj.opt(ch.toString()))
                        if (ing == null) good = false else grid[y * w + x] = ing
                    }
                    if (!good) { bad++; continue }
                    Recipes.add(Recipe(true, w, h, grid, emptyList(), res.first, res.second))
                    ok++
                } else {
                    val arr = j.optJSONArray("ingredients")
                    if (arr == null || arr.length() == 0 || arr.length() > 9) { bad++; continue }
                    val list = ArrayList<IntArray>()
                    var good = true
                    for (i in 0 until arr.length()) {
                        val ing = ingredient(arr.opt(i))
                        if (ing == null) good = false else list.add(ing)
                    }
                    if (!good) { bad++; continue }
                    Recipes.add(Recipe(false, 0, 0, emptyArray(), list, res.first, res.second))
                    ok++
                }
            }
            return Pair(ok, bad)
        }

        // ------------------------------------------------------------ modelos de bloco

        private fun firstModel(bs: JSONObject): String? {
            val v = bs.optJSONObject("variants")
            if (v != null) {
                val keys = ArrayList<String>()
                val it = v.keys()
                while (it.hasNext()) keys.add(it.next())
                if (keys.isEmpty()) return null
                val k = keys.firstOrNull { x -> x == "" || x == "normal" } ?: keys.sorted()[0]
                return modelOf(v.opt(k))
            }
            val mp = bs.optJSONArray("multipart")
            if (mp != null && mp.length() > 0) return modelOf(mp.optJSONObject(0)?.opt("apply"))
            return null
        }

        private fun modelOf(o: Any?): String? = when (o) {
            is JSONObject -> o.optString("model").ifEmpty { null }
            is JSONArray -> if (o.length() > 0) (o.optJSONObject(0)?.optString("model")?.ifEmpty { null }) else null
            else -> null
        }

        private fun split(ref: String, defNs: String): Pair<String, String> =
            if (ref.contains(':')) Pair(ref.substringBefore(':'), ref.substringAfter(':')) else Pair(defNs, ref)

        /** Devolve [topo, lado, base] como "ns:caminho" ou null se o modelo nao for um cubo inteiro. */
        private fun resolve(defNs: String, start: String): Array<String?>? {
            val tex = HashMap<String, String>()
            var kind: String? = null
            var own: HashMap<String, String>? = null
            var ref = start
            var depth = 0
            while (depth++ < 12) {
                val (ns, path) = split(ref, "minecraft")
                if (ns == "minecraft") { kind = path.removePrefix("block/"); break }
                val j = json("assets/$ns/models/$path.json") ?: return null
                val tj = j.optJSONObject("textures")
                if (tj != null) {
                    val it = tj.keys()
                    while (it.hasNext()) { val k = it.next(); if (!tex.containsKey(k)) tex[k] = tj.optString(k) }
                }
                if (own == null) {
                    val els = j.optJSONArray("elements")
                    if (els != null) {
                        if (els.length() != 1) return null
                        val el = els.getJSONObject(0)
                        if (!full(el.optJSONArray("from"), 0.0) || !full(el.optJSONArray("to"), 16.0)) return null
                        val fs = el.optJSONObject("faces") ?: return null
                        val m = HashMap<String, String>()
                        val it = fs.keys()
                        while (it.hasNext()) { val k = it.next(); m[k] = fs.getJSONObject(k).optString("texture") }
                        own = m
                    }
                }
                val parent = j.optString("parent", "")
                if (parent.isEmpty()) break
                ref = parent
            }

            fun t(name: String?): String? {
                if (name == null) return null
                var v = if (name.startsWith("#")) (tex[name.substring(1)] ?: return null)
                else (tex[name] ?: if (name.contains(':') || name.contains('/')) name else return null)
                var n = 0
                while (v.startsWith("#") && n++ < 10) v = tex[v.substring(1)] ?: return null
                val (ns, p) = split(v, "minecraft")
                return "$ns:$p"
            }

            val up: String?
            val down: String?
            val sd: String?
            val o = own
            if (o != null) {
                fun f(k: String) = t(o[k])
                up = f("up"); down = f("down"); sd = f("north") ?: f("east") ?: f("south") ?: f("west")
            } else when (kind) {
                "cube_all", "cube_mirrored_all", "leaves" -> { up = t("all"); down = up; sd = up }
                "cube_column", "cube_column_horizontal" -> { up = t("end"); down = up; sd = t("side") }
                "cube_bottom_top" -> { up = t("top"); down = t("bottom"); sd = t("side") }
                "cube_top" -> { up = t("top"); down = t("side"); sd = down }
                "orientable", "orientable_vertical" -> { up = t("top"); down = up; sd = t("side") ?: t("front") }
                "orientable_with_bottom" -> { up = t("top"); down = t("bottom"); sd = t("side") ?: t("front") }
                "cube", "cube_directional" -> { up = t("up"); down = t("down"); sd = t("north") ?: t("east") ?: t("south") ?: t("west") }
                else -> return null
            }
            val s = sd ?: up ?: down ?: return null
            return arrayOf(up ?: s, s, down ?: up ?: s)
        }

        private fun full(a: JSONArray?, v: Double): Boolean =
            a != null && a.length() == 3 && (0 until 3).all { Math.abs(a.optDouble(it, -1.0) - v) < 0.001 }
    }
}
