package com.voxelgame

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class Game(val world: World, private val input: Input) {
    companion object {
        const val HW = 0.3
        const val HEIGHT = 1.8
        const val EYE = 1.62
        const val DAY_LEN = 600f // segundos por dia completo
    }

    var px = 8.5
    var py = 80.0
    var pz = 8.5
    private var vx = 0.0
    private var vy = 0.0
    private var vz = 0.0
    var yaw = 0.0
    var pitch = -0.25
    private var onGround = false

    /** 0 = nascer do sol, 0.25 = meio-dia, 0.5 = por do sol, 0.75 = meia-noite. */
    var time = 0.2f
    var flying = false
    var inWater = false
    var underwater = false
    private var lastMin = -1

    var hitValid = false
    var hx = 0
    var hy = 0
    var hz = 0
    private var hnx = 0
    private var hny = 0
    private var hnz = 0
    private val look = FloatArray(2)

    init { respawn() }

    fun respawn() {
        world.chunk(0, 0)
        var y = H - 1
        while (y > 0 && world.get(8, y, 8) <= 0) y--
        px = 8.5; pz = 8.5; py = y + 1.0
        vx = 0.0; vy = 0.0; vz = 0.0
    }

    fun restore(s: SavedState) {
        px = s.px; py = s.py; pz = s.pz
        yaw = s.yaw; pitch = s.pitch
        time = s.time
        flying = s.flying
        vx = 0.0; vy = 0.0; vz = 0.0
        world.chunk(floor(px / 16.0).toInt(), floor(pz / 16.0).toInt())
        input.selected = s.selected.coerceIn(0, 7)
        for (i in 0 until 8) input.hotbar[i] = s.hotbar[i]
    }

    private fun collides(x: Double, y: Double, z: Double): Boolean {
        val x0 = floor(x - HW).toInt()
        val x1 = floor(x + HW - 1e-7).toInt()
        val y0 = floor(y).toInt()
        val y1 = floor(y + HEIGHT - 1e-7).toInt()
        val z0 = floor(z - HW).toInt()
        val z1 = floor(z + HW - 1e-7).toInt()
        for (bx in x0..x1) for (bz in z0..z1) for (by in y0..y1) {
            val b = world.get(bx, by, bz)
            if (b != 0 && b != Blocks.WATER) return true
        }
        return false
    }

    private fun canHop(nx: Double, nz: Double, intent: Boolean, alongX: Boolean): Boolean {
        if (!intent || flying || !(onGround || inWater)) return false
        return if (alongX) !collides(nx, py + 1.1, pz) else !collides(px, py + 1.1, nz)
    }

    private fun moveX(d: Double, intent: Boolean) {
        if (d == 0.0) return
        val nx = px + d
        if (!collides(nx, py, pz)) { px = nx; return }
        if (canHop(nx, pz, intent, true)) { vy = if (inWater) 6.5 else 8.4; onGround = false; return }
        vx = 0.0
        px = if (d > 0) floor(nx + HW) - HW - 1e-6 else floor(nx - HW) + 1.0 + HW + 1e-6
    }

    private fun moveZ(d: Double, intent: Boolean) {
        if (d == 0.0) return
        val nz = pz + d
        if (!collides(px, py, nz)) { pz = nz; return }
        if (canHop(px, nz, intent, false)) { vy = if (inWater) 6.5 else 8.4; onGround = false; return }
        vz = 0.0
        pz = if (d > 0) floor(nz + HW) - HW - 1e-6 else floor(nz - HW) + 1.0 + HW + 1e-6
    }

    private fun moveY(d: Double) {
        val ny = py + d
        if (!collides(px, ny, pz)) {
            py = ny
            if (d != 0.0) onGround = false
            return
        }
        if (d < 0) {
            py = floor(ny) + 1.0
            onGround = true
        } else {
            py = floor(ny + HEIGHT) - HEIGHT - 1e-6
        }
        vy = 0.0
    }

    fun update(dt: Float) {
        input.takeLook(look)
        yaw -= look[0].toDouble()
        pitch = (pitch - look[1].toDouble()).coerceIn(-1.54, 1.54)

        time = (time + dt / DAY_LEN) % 1f
        if (input.flyToggle) {
            input.flyToggle = false
            flying = !flying
            vy = 0.0
        }

        val fx = floor(px).toInt()
        val fz = floor(pz).toInt()
        inWater = world.get(fx, floor(py + 0.5).toInt(), fz) == Blocks.WATER
        underwater = world.get(fx, floor(py + EYE).toInt(), fz) == Blocks.WATER

        val mx = input.moveX.toDouble()
        val my = input.moveY.toDouble()
        val mag = min(1.0, hypot(mx, my))
        var speed = if (mag > 0.92) 5.8 else 4.3
        if (flying) speed *= 2.0 else if (inWater) speed *= 0.6
        val sy = sin(yaw)
        val cy = cos(yaw)
        var wx = cy * mx - sy * my
        var wz = -sy * mx - cy * my
        val wl = hypot(wx, wz)
        if (wl > 1.0) { wx /= wl; wz /= wl }
        val dtd = dt.toDouble()
        val k = min(1.0, (if (flying) 8.0 else if (onGround) 16.0 else 5.0) * dtd)
        vx += (wx * speed - vx) * k
        vz += (wz * speed - vz) * k

        if (input.jump && onGround && !flying && !inWater) { vy = 8.7; onGround = false }

        val steps = ceil(dtd / 0.008).toInt().coerceIn(1, 10)
        val h = dtd / steps
        val intent = mag > 0.15
        for (i in 0 until steps) {
            if (flying) {
                val up = (if (input.jump) 1.0 else 0.0) - (if (input.down) 1.0 else 0.0)
                vy += (up * 9.0 - vy) * min(1.0, 8.0 * h)
            } else if (inWater) {
                val target = if (input.jump) 3.6 else -1.8
                vy += (target - vy) * min(1.0, 5.0 * h)
            } else {
                vy = max(vy - 28.0 * h, -55.0)
            }
            moveX(vx * h, intent)
            moveZ(vz * h, intent)
            moveY(vy * h)
        }
        if (py < -30) respawn()

        raycast(5.0)
        if (input.breakReq) {
            input.breakReq = false
            if (hitValid && hy > 0) world.set(hx, hy, hz, 0)
        }
        if (input.placeReq) {
            input.placeReq = false
            if (hitValid) place()
        }

        Stats.x = floor(px).toInt()
        Stats.y = floor(py).toInt()
        Stats.z = floor(pz).toInt()
        Stats.underwater = underwater
        Stats.flying = flying
        val mins = (((time * 24f + 6f) % 24f) * 60f).toInt()
        if (mins != lastMin) {
            lastMin = mins
            Stats.clock = String.format("%02d:%02d", mins / 60, mins % 60)
        }
    }

    private fun place() {
        val bx = hx + hnx
        val by = hy + hny
        val bz = hz + hnz
        if (by < 0 || by >= H) return
        val cur = world.get(bx, by, bz)
        if (cur != 0 && cur != Blocks.WATER) return
        if (px + HW > bx && px - HW < bx + 1 && py + HEIGHT > by && py < by + 1 && pz + HW > bz && pz - HW < bz + 1) return
        world.set(bx, by, bz, input.hotbar[input.selected.coerceIn(0, 7)])
    }

    private fun raycast(maxDist: Double) {
        hitValid = false
        val ox = px
        val oy = py + EYE
        val oz = pz
        val dx = -sin(yaw) * cos(pitch)
        val dy = sin(pitch)
        val dz = -cos(yaw) * cos(pitch)
        var x = floor(ox).toInt()
        var y = floor(oy).toInt()
        var z = floor(oz).toInt()
        val sx = if (dx > 0) 1 else -1
        val sy = if (dy > 0) 1 else -1
        val sz = if (dz > 0) 1 else -1
        val big = 1e30
        val tdx = if (dx != 0.0) abs(1.0 / dx) else big
        val tdy = if (dy != 0.0) abs(1.0 / dy) else big
        val tdz = if (dz != 0.0) abs(1.0 / dz) else big
        var tmx = if (dx == 0.0) big else (if (dx > 0) (x + 1 - ox) else (ox - x)) * tdx
        var tmy = if (dy == 0.0) big else (if (dy > 0) (y + 1 - oy) else (oy - y)) * tdy
        var tmz = if (dz == 0.0) big else (if (dz > 0) (z + 1 - oz) else (oz - z)) * tdz
        var nx = 0
        var ny = 0
        var nz = 0
        var t = 0.0
        while (t <= maxDist) {
            val b = world.get(x, y, z)
            if (b < 0) return
            if (b > 0 && b != Blocks.WATER && (nx != 0 || ny != 0 || nz != 0)) {
                hitValid = true
                hx = x; hy = y; hz = z
                hnx = nx; hny = ny; hnz = nz
                return
            }
            if (tmx < tmy && tmx < tmz) {
                x += sx; t = tmx; tmx += tdx; nx = -sx; ny = 0; nz = 0
            } else if (tmy < tmz) {
                y += sy; t = tmy; tmy += tdy; nx = 0; ny = -sy; nz = 0
            } else {
                z += sz; t = tmz; tmz += tdz; nx = 0; ny = 0; nz = -sz
            }
        }
    }
}
