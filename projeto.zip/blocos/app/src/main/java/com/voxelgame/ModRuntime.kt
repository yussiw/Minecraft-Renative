package com.voxelgame

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import org.json.JSONObject
import org.luaj.vm2.Globals
import org.luaj.vm2.LuaFunction
import org.luaj.vm2.LuaTable
import org.luaj.vm2.LuaValue
import org.luaj.vm2.Varargs
import org.luaj.vm2.lib.OneArgFunction
import org.luaj.vm2.lib.TwoArgFunction
import org.luaj.vm2.lib.VarArgFunction
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Runtime inicial do formato .javl (ZIP + manifest.json + scripts/main.lua). */
object ModRuntime {
    private const val API_VERSION = 1
    private const val MAX_ARCHIVE = 32L * 1024L * 1024L
    private const val MAX_ENTRY = 8L * 1024L * 1024L
    private const val MAX_TOTAL = 64L * 1024L * 1024L

    data class PauseButton(val modId: String, val label: String, val action: LuaFunction)
    data class ModInfo(val id: String, val name: String, val version: String, val enabled: Boolean, val error: String? = null)

    private data class LoadedMod(
        val id: String, val name: String, val version: String, val file: File,
        val globals: Globals, val callbacks: MutableMap<String, LuaFunction>,
        val pauseButtons: MutableList<PauseButton>
    )

    private val lock = Any()
    private val loaded = LinkedHashMap<String, LoadedMod>()
    private val errors = LinkedHashMap<String, String>()
    private var soundPool: SoundPool? = null
    private val soundSamples = HashMap<String, Int>()
    private val readySamples = HashSet<Int>()
    private val pendingSounds = HashMap<Int, MutableList<Float>>()
    @Volatile private var appContext: Context? = null
    @Volatile private var currentGame: Game? = null

    fun initialize(context: Context, game: Game) {
        synchronized(lock) {
            appContext = context.applicationContext
            currentGame = game
            loaded.clear()
            errors.clear()
            soundSamples.clear()
            readySamples.clear()
            pendingSounds.clear()
            soundPool?.release()
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            soundPool = SoundPool.Builder().setMaxStreams(16).setAudioAttributes(attrs).build().also { pool ->
                pool.setOnLoadCompleteListener { p, sampleId, status ->
                    synchronized(lock) {
                        if (status == 0) {
                            readySamples.add(sampleId)
                            pendingSounds.remove(sampleId)?.forEach { volume -> p.play(sampleId, volume, volume, 0, 0, 1f) }
                        } else pendingSounds.remove(sampleId)
                    }
                }
            }
            val dir = modsDir(context)
            dir.listFiles { f -> f.isFile && f.extension.equals("javl", true) }
                ?.sortedBy { it.name.lowercase(Locale.ROOT) }
                ?.forEach { loadLocked(it) }
            applyMergedTextures(context)
            dispatchLocked("on_game_start")
        }
    }

    fun shutdown() {
        synchronized(lock) {
            dispatchLocked("on_game_stop")
            loaded.clear()
            currentGame = null
            soundPool?.release()
            soundPool = null
            soundSamples.clear(); readySamples.clear(); pendingSounds.clear()
        }
    }

    fun tick(dt: Float) {
        synchronized(lock) {
            val args = LuaValue.varargsOf(arrayOf(LuaValue.valueOf(dt.toDouble())))
            dispatchLocked("on_tick", args)
        }
    }

    fun dispatch(event: String) { synchronized(lock) { dispatchLocked(event) } }

    private fun dispatchLocked(event: String, args: Varargs = LuaValue.NONE) {
        loaded.values.toList().forEach { mod ->
            try { mod.callbacks[event]?.invoke(args) }
            catch (t: Throwable) { errors[mod.id] = "Erro em $event: ${t.message ?: t.javaClass.simpleName}" }
        }
    }

    fun pauseButtons(): List<PauseButton> = synchronized(lock) { loaded.values.flatMap { it.pauseButtons }.toList() }

    fun list(context: Context): List<ModInfo> {
        synchronized(lock) {
            val dir = modsDir(context)
            val result = ArrayList<ModInfo>()
            dir.listFiles { f -> f.isFile && f.extension.equals("javl", true) }
                ?.sortedBy { it.name.lowercase(Locale.ROOT) }
                ?.forEach { file ->
                    val id = file.nameWithoutExtension
                    val m = loaded[id]
                    if (m != null) result.add(ModInfo(m.id, m.name, m.version, true, errors[id]))
                    else result.add(readInfo(file, errors[id]))
                }
            return result
        }
    }

    fun install(context: Context, input: InputStream): String {
        val dir = modsDir(context)
        if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Não foi possível criar a pasta de mods")
        val temp = File(dir, "import_${System.nanoTime()}.tmp")
        try {
            var count = 0L
            temp.outputStream().use { out ->
                val buf = ByteArray(8192)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    count += n
                    if (count > MAX_ARCHIVE) throw IllegalArgumentException("Arquivo .javl excede 32 MB")
                    out.write(buf, 0, n)
                }
            }
            val manifest = readManifest(temp)
            val id = manifest.getString("id")
            validateId(id)
            val target = File(dir, "$id.javl")
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) temp.copyTo(target, true)
            val didLoad = synchronized(lock) {
                loaded.remove(id)
                errors.remove(id)
                loadLocked(target)
                applyMergedTextures(context)
                loaded.containsKey(id)
            }
            return if (didLoad) "${manifest.optString("name", id)} importado e carregado."
            else "Arquivo importado, mas o script falhou ao carregar: ${errors[id] ?: "erro desconhecido"}"
        } finally { temp.delete() }
    }

    fun remove(context: Context, id: String) {
        validateId(id)
        synchronized(lock) {
            loaded.remove(id)
            errors.remove(id)
            File(modsDir(context), "$id.javl").delete()
            appContext?.let { applyMergedTextures(it) }
        }
    }

    fun reload(context: Context, game: Game) = initialize(context, game)

    private fun modsDir(context: Context) = File(context.filesDir, "mods")

    private fun validateId(id: String) {
        require(id.matches(Regex("[a-zA-Z0-9_.-]{1,48}"))) { "ID inválido no manifest.json" }
    }

    private fun readManifest(file: File): JSONObject {
        ZipFile(file).use { zip ->
            var total = 0L
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val normalized = e.name.replace('\\', '/')
                if (normalized.startsWith("/") || normalized.split('/').contains("..") || normalized.contains(':')) {
                    throw IllegalArgumentException("Caminho inseguro dentro do .javl")
                }
                if (e.size > MAX_ENTRY) throw IllegalArgumentException("Arquivo interno excede 8 MB: ${e.name}")
                if (e.size > 0) { total += e.size; if (total > MAX_TOTAL) throw IllegalArgumentException("Conteúdo descompactado excede 64 MB") }
            }
            val entry = zip.getEntry("manifest.json") ?: throw IllegalArgumentException("Falta manifest.json na raiz do .javl")
            if (entry.size > 64 * 1024) throw IllegalArgumentException("manifest.json muito grande")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(text)
            val id = json.getString("id")
            validateId(id)
            if (!json.has("name") || !json.has("version")) throw IllegalArgumentException("manifest precisa de name e version")
            val api = json.optInt("api_version", 1)
            if (api > API_VERSION || api < 1) throw IllegalArgumentException("API do mod incompatível: $api (suportada: $API_VERSION)")
            val script = json.optString("entry", "scripts/main.lua")
            require(!script.startsWith("/") && !script.contains("..") && script.endsWith(".lua")) { "Caminho entry inválido" }
            if (zip.getEntry(script) == null) throw IllegalArgumentException("Script principal não encontrado: $script")
            return json
        }
    }

    private fun readInfo(file: File, error: String? = null): ModInfo = try {
        val j = readManifest(file)
        ModInfo(j.getString("id"), j.getString("name"), j.getString("version"), false, error)
    } catch (t: Throwable) { ModInfo(file.nameWithoutExtension, file.name, "inválido", false, error ?: t.message) }

    private fun loadLocked(file: File) {
        var id = file.nameWithoutExtension
        try {
            val manifest = readManifest(file)
            id = manifest.getString("id")
            val name = manifest.getString("name")
            val version = manifest.getString("version")
            val entryName = manifest.optString("entry", "scripts/main.lua")
            val script = ZipFile(file).use { zip ->
                val e = zip.getEntry(entryName) ?: error("Script principal ausente")
                if (e.size > MAX_ENTRY) error("Script principal excede 8 MB")
                zip.getInputStream(e).bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
            val callbacks = HashMap<String, LuaFunction>()
            val buttons = ArrayList<PauseButton>()
            val globals = JsePlatform.standardGlobals()
            // Remoção de APIs de sistema: os mods não recebem IO, shell, reflection ou carregamento Java.
            listOf("io", "os", "package", "debug", "luajava", "dofile", "loadfile", "require", "module", "collectgarbage", "load", "loadstring").forEach { globals.set(it, LuaValue.NIL) }
            globals.set("print", object : VarArgFunction() {
                override fun invoke(args: Varargs): Varargs {
                    android.util.Log.i("JAVL/$id", (1..args.narg()).joinToString(" ") { args.arg(it).tojstring() })
                    return LuaValue.NONE
                }
            })
            val api = LuaTable()
            api.set("log", object : OneArgFunction() {
                override fun call(arg: LuaValue): LuaValue { android.util.Log.i("JAVL/$id", arg.tojstring()); return LuaValue.NIL }
            })
            api.set("on", object : TwoArgFunction() {
                override fun call(event: LuaValue, fn: LuaValue): LuaValue {
                    require(event.isstring() && fn.isfunction()) { "mods.on(event, function) esperado" }
                    val raw = event.checkjstring()
                    val key = when (raw) { "tick" -> "on_tick"; "game_start" -> "on_game_start"; "game_stop" -> "on_game_stop"; else -> if (raw.startsWith("on_")) raw else "on_$raw" }
                    callbacks[key] = fn.checkfunction()
                    return LuaValue.NIL
                }
            })
            api.set("add_pause_button", object : TwoArgFunction() {
                override fun call(label: LuaValue, fn: LuaValue): LuaValue {
                    require(label.isstring() && fn.isfunction()) { "mods.add_pause_button(label, function) esperado" }
                    if (buttons.size >= 8) error("Limite de 8 botões extras por mod")
                    buttons.add(PauseButton(id, label.checkjstring().take(32), fn.checkfunction()))
                    return LuaValue.NIL
                }
            })
            api.set("asset_text", object : OneArgFunction() {
                override fun call(path: LuaValue): LuaValue {
                    val p = safeAssetPath(path.checkjstring())
                    val content = ZipFile(file).use { zip ->
                        val e = zip.getEntry(p) ?: return LuaValue.NIL
                        if (e.size > MAX_ENTRY) error("Asset excede 8 MB")
                        zip.getInputStream(e).bufferedReader(Charsets.UTF_8).use { it.readText() }
                    }
                    return LuaValue.valueOf(content)
                }
            })
            api.set("play_sound", object : VarArgFunction() {
                override fun invoke(args: Varargs): Varargs {
                    if (args.narg() < 1) error("mods.play_sound(path, volume=1.0)")
                    val volume = if (args.narg() >= 2) args.arg(2).checkdouble().toFloat().coerceIn(0f, 1f) else 1f
                    return LuaValue.valueOf(playSound(id, file, args.arg(1).checkjstring(), volume))
                }
            })
            api.set("get_version", LuaValue.valueOf("$API_VERSION"))
            globals.set("mods", api)
            globals.set("game", createGameApi())
            globals.load(script, "$id:$entryName").call()
            loaded[id] = LoadedMod(id, name, version, file, globals, callbacks, buttons)
            errors.remove(id)
            android.util.Log.i("JAVL", "Mod carregado: $name ($id) v$version")
        } catch (t: Throwable) {
            errors[id] = t.message ?: t.javaClass.simpleName
            android.util.Log.e("JAVL", "Falha ao carregar $id", t)
        }
    }

    private fun safeAssetPath(raw: String): String {
        val p = raw.replace('\\', '/')
        require(p.isNotBlank() && !p.startsWith('/') && !p.split('/').contains("..") && !p.contains(':')) { "Caminho de asset inválido" }
        return p
    }

    /** Mescla texturas PNG do resource pack base e dos mods; mods em ordem alfabética sobrescrevem o anterior. */
    private fun applyMergedTextures(context: Context) {
        val merged = LinkedHashMap<String, ByteArray>()
        var mergedBytes = 0L
        fun collect(file: File) {
            if (!file.isFile) return
            try {
                ZipFile(file).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val name = e.name.replace('\\', '/')
                        if (e.isDirectory || !name.startsWith("assets/minecraft/textures/") || !name.endsWith(".png", true)) continue
                        if (e.size > MAX_ENTRY) continue
                        val bytes = zip.getInputStream(e).use { input ->
                            val out = ByteArrayOutputStream()
                            val buffer = ByteArray(8192)
                            var total = 0
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                total += n
                                if (total > MAX_ENTRY) throw IllegalArgumentException("Textura muito grande")
                                out.write(buffer, 0, n)
                            }
                            out.toByteArray()
                        }
                        val previous = merged[name]?.size ?: 0
                        if (mergedBytes - previous + bytes.size > MAX_TOTAL) continue
                        mergedBytes = mergedBytes - previous + bytes.size
                        merged[name] = bytes
                    }
                }
            } catch (t: Throwable) { android.util.Log.w("JAVL", "Texturas ignoradas em ${file.name}: ${t.message}") }
        }
        collect(File(context.filesDir, "pack.zip"))
        loaded.values.forEach { collect(it.file) }
        if (merged.isEmpty()) return
        val outFile = File(context.cacheDir, "javl_merged_textures.zip")
        try {
            ZipOutputStream(outFile.outputStream().buffered()).use { out ->
                merged.forEach { (name, bytes) ->
                    out.putNextEntry(ZipEntry(name)); out.write(bytes); out.closeEntry()
                }
            }
            val count = Atlas.loadPack(outFile.absolutePath)
            android.util.Log.i("JAVL", "Atlas atualizado com $count texturas de resource packs/mods")
        } catch (t: Throwable) {
            android.util.Log.e("JAVL", "Falha ao mesclar texturas", t)
        } finally { outFile.delete() }
    }

    private fun playSound(modId: String, archive: File, rawPath: String, volume: Float): Boolean {
        val path = safeAssetPath(rawPath)
        require(path.lowercase(Locale.ROOT).endsWith(".ogg") || path.lowercase(Locale.ROOT).endsWith(".wav") || path.lowercase(Locale.ROOT).endsWith(".mp3")) {
            "Som precisa ser OGG, WAV ou MP3"
        }
        val key = "$modId/$path"
        val pool = soundPool ?: return false
        val sample = soundSamples[key]
        if (sample != null) {
            if (readySamples.contains(sample)) pool.play(sample, volume, volume, 0, 0, 1f)
            else pendingSounds.getOrPut(sample) { ArrayList() }.add(volume)
            return true
        }
        val context = appContext ?: return false
        val entryBytes = ZipFile(archive).use { zip ->
            val entry = zip.getEntry(path) ?: return false
            if (entry.size > MAX_ENTRY) error("Arquivo de áudio excede 8 MB")
            zip.getInputStream(entry).use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_ENTRY) error("Arquivo de áudio excede 8 MB")
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
        }
        val safeName = path.replace('/', '_')
        val target = File(File(context.cacheDir, "javl_audio/$modId"), safeName)
        target.parentFile?.mkdirs()
        target.writeBytes(entryBytes)
        val id = pool.load(target.absolutePath, 1)
        if (id == 0) return false
        soundSamples[key] = id
        if (readySamples.contains(id)) pool.play(id, volume, volume, 0, 0, 1f)
        else pendingSounds.getOrPut(id) { ArrayList() }.add(volume)
        return true
    }

    private fun createGameApi(): LuaTable {
        val table = LuaTable()
        table.set("get_time", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs = LuaValue.valueOf((currentGame?.time ?: 0f).toDouble())
        })
        table.set("set_time", object : OneArgFunction() {
            override fun call(arg: LuaValue): LuaValue { currentGame?.time = (arg.checkdouble().toFloat() % 1f + 1f) % 1f; return LuaValue.NIL }
        })
        table.set("is_creative", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs = LuaValue.valueOf(currentGame?.creative ?: false)
        })
        table.set("set_creative", object : OneArgFunction() {
            override fun call(arg: LuaValue): LuaValue { currentGame?.creative = arg.toboolean(); return LuaValue.NIL }
        })
        table.set("get_player_position", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val g = currentGame ?: return LuaValue.NONE
                return LuaValue.varargsOf(arrayOf(LuaValue.valueOf(g.px), LuaValue.valueOf(g.py), LuaValue.valueOf(g.pz)))
            }
        })
        table.set("set_player_position", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val g = currentGame ?: return LuaValue.NONE
                if (args.narg() < 3) error("game.set_player_position(x, y, z)")
                g.px = args.arg(1).checkdouble(); g.py = args.arg(2).checkdouble(); g.pz = args.arg(3).checkdouble()
                return LuaValue.NONE
            }
        })
        table.set("get_health", object : VarArgFunction() { override fun invoke(args: Varargs) = LuaValue.valueOf((currentGame?.health ?: 0f).toDouble()) })
        table.set("set_health", object : OneArgFunction() { override fun call(arg: LuaValue): LuaValue { currentGame?.health = arg.checkdouble().toFloat().coerceIn(0f, 20f); return LuaValue.NIL } })
        table.set("get_food", object : VarArgFunction() { override fun invoke(args: Varargs) = LuaValue.valueOf(currentGame?.food ?: 0) })
        table.set("set_food", object : OneArgFunction() { override fun call(arg: LuaValue): LuaValue { currentGame?.food = arg.checkint().coerceIn(0, 20); return LuaValue.NIL } })
        table.set("get_block", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val g = currentGame ?: return LuaValue.NONE
                if (args.narg() < 3) error("game.get_block(x, y, z)")
                return LuaValue.valueOf(g.world.get(args.arg(1).checkint(), args.arg(2).checkint(), args.arg(3).checkint()))
            }
        })
        table.set("set_block", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val g = currentGame ?: return LuaValue.NONE
                if (args.narg() < 4) error("game.set_block(x, y, z, block_id)")
                val x = args.arg(1).checkint(); val y = args.arg(2).checkint(); val z = args.arg(3).checkint()
                val block = args.arg(4).checkint()
                if (block !in 0..Blocks.MAX_BLOCK) error("block_id inválido")
                g.world.chunk(x shr 4, z shr 4)
                g.world.set(x, y, z, block)
                return LuaValue.NONE
            }
        })
        return table
    }

    fun clickPauseButton(button: PauseButton) {
        synchronized(lock) {
            try { button.action.call() }
            catch (t: Throwable) { errors[button.modId] = "Erro no botão: ${t.message ?: t.javaClass.simpleName}" }
        }
    }
}
