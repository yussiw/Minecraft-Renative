package com.voxelgame

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Atlas de texturas. Por padrao e gerado por codigo (nenhum asset externo).
 * Se o usuario escolher um resource pack (.zip no formato do Minecraft), as texturas
 * dele substituem as geradas; o que faltar no pack continua usando a versao gerada.
 */
object Atlas {
    const val TILES = 8
    const val COUNT = 19
    const val MAX_TS = 128

    private const val DIR = "assets/minecraft/textures/block/"
    private const val DIR_OLD = "assets/minecraft/textures/blocks/"
    private val GRASS_TINT = 0xFF91BD59.toInt()
    private val FOLIAGE_TINT = 0xFF77AB2F.toInt()
    private val WATER_TINT = 0xFF3F76E4.toInt()

    private val procedural: Array<IntArray> = makeProcedural()

    @Volatile var ts = 16
        private set
    @Volatile var bitmap: Bitmap = compose(procedural, 16)
        private set
    val version = AtomicInteger(0)

    // ------------------------------------------------------------ gerado por codigo

    private fun r(x: Int, y: Int, s: Int): Float = (Noise.hash(x, y, s * 7919 + 13) and 0xFFFF) / 65535f

    private fun col(rr: Int, gg: Int, bb: Int, v: Float): Int {
        val f = 1f + v
        return Color.rgb(
            (rr * f).toInt().coerceIn(0, 255),
            (gg * f).toInt().coerceIn(0, 255),
            (bb * f).toInt().coerceIn(0, 255)
        )
    }

    private fun makeProcedural(): Array<IntArray> {
        val t = Array(COUNT) { IntArray(16 * 16) }
        for (y in 0 until 16) {
            for (x in 0 until 16) {
                val i = y * 16 + x
                t[0][i] = col(95, 165, 60, (r(x, y, 2) - 0.5f) * 0.35f)
                val fringe = 3 + (r(x, 0, 3) * 3f).toInt()
                t[1][i] = if (y < fringe) col(95, 165, 60, (r(x, y, 4) - 0.5f) * 0.35f)
                else col(134, 96, 67, (r(x, y, 5) - 0.5f) * 0.3f)
                t[2][i] = col(134, 96, 67, (r(x, y, 6) - 0.5f) * 0.3f)
                t[3][i] = col(125, 125, 125, (r(x, y, 7) - 0.5f) * 0.28f)
                t[4][i] = col(219, 207, 150, (r(x, y, 8) - 0.5f) * 0.10f)
                t[5][i] = col(104, 82, 50, (r(x, 0, 9) - 0.5f) * 0.45f + (r(x, y, 10) - 0.5f) * 0.12f)
                val dd = sqrt((x - 7.5f) * (x - 7.5f) + (y - 7.5f) * (y - 7.5f))
                val edge = x == 0 || y == 0 || x == 15 || y == 15
                t[6][i] = if (edge) col(104, 82, 50, (r(x, y, 11) - 0.5f) * 0.2f)
                else col(176, 140, 84, sin(dd * 1.7f) * 0.10f + (r(x, y, 12) - 0.5f) * 0.06f)
                t[7][i] = if (r(x, y, 13) > 0.82f) col(28, 80, 22, 0f)
                else col(54, 124, 38, (r(x, y, 14) - 0.5f) * 0.45f)
                val joint = ((y / 4) % 2) * 8
                val dark = (y % 4 == 3) || x == joint
                t[8][i] = col(164, 131, 79, (if (dark) -0.22f else 0f) + (r(x, y, 15) - 0.5f) * 0.10f)
                val cell = Noise.hash(x / 4, y / 4, 99)
                val shade = ((cell and 0xFF) / 255f - 0.5f) * 0.35f
                val e2 = (x % 4 == 0) || (y % 4 == 0)
                t[9][i] = col(118, 118, 118, shade + (if (e2) -0.22f else 0f) + (r(x, y, 16) - 0.5f) * 0.08f)
                // neve
                t[10][i] = col(240, 245, 252, (r(x, y, 17) - 0.5f) * 0.07f)
                // cascalho
                val gv = Noise.hash(x / 2, y / 2, 55)
                t[11][i] = col(132, 128, 124, ((gv and 0xFF) / 255f - 0.5f) * 0.55f + (r(x, y, 18) - 0.5f) * 0.12f)
                // vidro (borda opaca, miolo transparente)
                val gEdge = x == 0 || y == 0 || x == 15 || y == 15
                val gShine = (x + y == 6) || (x + y == 7) || (x + y == 12)
                t[12][i] = if (gEdge) Color.argb(255, 205, 232, 240)
                else if (gShine && x > 1 && y > 1 && x < 14 && y < 14) Color.argb(120, 255, 255, 255)
                else 0
                // agua (semi-transparente)
                val wv = col(36, 92, 205, (r(x, y, 19) - 0.5f) * 0.18f)
                t[13][i] = (175 shl 24) or (wv and 0xFFFFFF)
                // tijolos
                val mortar = (y % 4 == 3) || (x + (if ((y / 4) % 2 == 0) 0 else 4)) % 8 == 7
                t[14][i] = if (mortar) col(176, 170, 160, (r(x, y, 20) - 0.5f) * 0.10f)
                else col(152, 76, 58, (r(x, y, 21) - 0.5f) * 0.22f)
                // maca (item)
                val ax = x - 7.5f
                val ay = y - 9f
                val ad = Math.sqrt((ax * ax + ay * ay * 1.1f).toDouble()).toFloat()
                t[15][i] = if (x == 8 && y in 2..4) col(110, 78, 40, 0f)
                else if ((x in 9..11 && y == 3) || (x in 10..11 && y == 2)) col(70, 150, 40, 0f)
                else if (ad < 5.3f) {
                    val hl = if (ax < -1.5f && ay < -1f) 0.22f else if (ax > 1.5f && ay > 1.5f) -0.2f else 0f
                    col(205, 32, 32, hl + (r(x, y, 22) - 0.5f) * 0.1f)
                } else 0
                // grama alta (planta)
                val bh = 5 + (r(x, 0, 30) * 9f).toInt()
                val blade = y >= 16 - bh && r(x, 1, 31) > 0.2f
                t[16][i] = if (blade) col(98, 170, 58, ((16 - y) / 16f) * 0.25f - 0.1f + (r(x, y, 32) - 0.5f) * 0.15f) else 0
                // dente-de-leao
                val dStem = x == 8 && y in 8..15
                val dLeaf = (x == 7 && y == 12) || (x == 9 && y == 11)
                val dCenter = x in 7..9 && y in 5..6
                val dPetal = x in 6..10 && y in 4..7 && !((x == 6 || x == 10) && (y == 4 || y == 7))
                t[17][i] = if (dCenter) col(235, 160, 20, 0f)
                else if (dPetal) col(250, 215, 30, (r(x, y, 33) - 0.5f) * 0.15f)
                else if (dStem || dLeaf) col(60, 130, 40, 0f) else 0
                // margarida
                val mx = Math.abs(x - 8)
                val my = Math.abs(y - 5)
                val mCenter = mx <= 1 && my <= 1
                val mRing = mx <= 3 && my <= 2 && !(mx == 3 && my == 2)
                t[18][i] = if (mCenter) col(240, 190, 30, 0f)
                else if (mRing) col(245, 245, 245, (r(x, y, 34) - 0.5f) * 0.08f)
                else if (dStem || dLeaf) col(60, 130, 40, 0f) else 0
            }
        }
        return t
    }

    // ------------------------------------------------------------ montagem do atlas

    private fun scale(src: IntArray, sw: Int, dw: Int): IntArray {
        if (sw == dw) return src
        val out = IntArray(dw * dw)
        for (y in 0 until dw) {
            val sy = y * sw / dw
            for (x in 0 until dw) out[y * dw + x] = src[sy * sw + x * sw / dw]
        }
        return out
    }

    private fun compose(tiles: Array<IntArray>, size: Int): Bitmap {
        val side = TILES * size
        val pix = IntArray(side * side)
        for (t in 0 until COUNT) {
            val tx = (t % TILES) * size
            val ty = (t / TILES) * size
            val px = tiles[t]
            for (y in 0 until size) {
                System.arraycopy(px, y * size, pix, (ty + y) * side + tx, size)
            }
        }
        val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pix, 0, side, 0, 0, side, side)
        return bmp
    }

    // ------------------------------------------------------------ resource pack

    private class Tex(val px: IntArray, val size: Int)

    private fun decode(zf: ZipFile, e: ZipEntry): Tex? {
        val bmp = zf.getInputStream(e).use { BitmapFactory.decodeStream(it) } ?: return null
        val w = bmp.width
        if (w < 4 || bmp.height < w) return null
        val px = IntArray(w * w)
        bmp.getPixels(px, 0, w, 0, 0, w, w) // se for animada (varios quadros), usa o primeiro
        bmp.recycle()
        return Tex(px, w)
    }

    /** Texturas de grama/folhas do Minecraft vem em cinza e sao pintadas pelo bioma. */
    private fun isGray(px: IntArray): Boolean {
        var sum = 0L
        var n = 0
        for (p in px) {
            if ((p ushr 24) < 128) continue
            sum += Math.abs(Color.red(p) - Color.green(p)) + Math.abs(Color.green(p) - Color.blue(p))
            n++
        }
        return n > 0 && sum / n < 14
    }

    private fun tint(px: IntArray, color: Int) {
        val tr = Color.red(color)
        val tg = Color.green(color)
        val tb = Color.blue(color)
        for (i in px.indices) {
            val p = px[i]
            px[i] = Color.argb(
                p ushr 24,
                Color.red(p) * tr / 255,
                Color.green(p) * tg / 255,
                Color.blue(p) * tb / 255
            )
        }
    }

    private fun over(base: Int, top: Int): Int {
        val a = top ushr 24
        if (a == 255) return top
        if (a == 0) return base
        val ia = 255 - a
        return Color.rgb(
            (Color.red(top) * a + Color.red(base) * ia) / 255,
            (Color.green(top) * a + Color.green(base) * ia) / 255,
            (Color.blue(top) * a + Color.blue(base) * ia) / 255
        )
    }

    /** Carrega o pack. Devolve quantas das 19 texturas foram encontradas (0 = pack invalido). */
    fun loadPack(path: String): Int {
        ZipFile(path).use { zf ->
            val modern = HashMap<String, ZipEntry>()
            val legacy = HashMap<String, ZipEntry>()
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                if (e.isDirectory) continue
                val n = e.name.replace('\\', '/')
                if (!n.endsWith(".png")) continue
                val mi = n.indexOf(DIR)
                if (mi >= 0) {
                    val rest = n.substring(mi + DIR.length)
                    if (!rest.contains('/')) modern[rest.removeSuffix(".png")] = e
                }
                val li = n.indexOf(DIR_OLD)
                if (li >= 0) {
                    val rest = n.substring(li + DIR_OLD.length)
                    if (!rest.contains('/')) legacy[rest.removeSuffix(".png")] = e
                }
            }

            fun get(m: String, l: String?): Tex? {
                val e = modern[m] ?: (if (l != null) legacy[l] else null) ?: return null
                return try { decode(zf, e) } catch (t: Throwable) { null }
            }

            val found = arrayOfNulls<Tex>(COUNT)
            found[0] = get("grass_block_top", "grass_top")?.also { if (isGray(it.px)) tint(it.px, GRASS_TINT) }

            val side = get("grass_block_side", "grass_side")
            val overlay = get("grass_block_side_overlay", "grass_side_overlay")
            if (side != null) {
                if (overlay != null) {
                    if (isGray(overlay.px)) tint(overlay.px, GRASS_TINT)
                    val o = scale(overlay.px, overlay.size, side.size)
                    for (i in side.px.indices) side.px[i] = over(side.px[i], o[i])
                }
                found[1] = side
            }
            found[2] = get("dirt", "dirt")
            found[3] = get("stone", "stone")
            found[4] = get("sand", "sand")
            found[5] = get("oak_log", "log_oak")
            found[6] = get("oak_log_top", "log_oak_top")
            found[7] = get("oak_leaves", "leaves_oak")?.also {
                if (isGray(it.px)) tint(it.px, FOLIAGE_TINT)
                for (i in it.px.indices) it.px[i] = over(Color.rgb(28, 70, 20), it.px[i]) // furos viram sombra
            }
            found[8] = get("oak_planks", "planks_oak")
            found[9] = get("cobblestone", "cobblestone")
            found[10] = get("snow", "snow")
            found[11] = get("gravel", "gravel")
            found[12] = get("glass", "glass")
            found[13] = get("water_still", "water_still")?.also {
                if (isGray(it.px)) tint(it.px, WATER_TINT)
                for (i in it.px.indices) it.px[i] = (175 shl 24) or (it.px[i] and 0xFFFFFF)
            }
            found[14] = get("bricks", "brick")
            found[16] = get("short_grass", "tallgrass")?.also { if (isGray(it.px)) tint(it.px, FOLIAGE_TINT) }
            found[17] = get("dandelion", "flower_dandelion")
            found[18] = get("oxeye_daisy", "flower_oxeye_daisy")

            val count = found.count { it != null }
            if (count == 0) return 0

            var size = 16
            for (f in found) if (f != null) size = max(size, f.size)
            var p2 = 16
            while (p2 < size && p2 < MAX_TS) p2 *= 2

            val tiles = Array(COUNT) { i ->
                val f = found[i]
                if (f != null) scale(f.px, f.size, p2) else scale(procedural[i], 16, p2)
            }
            val bmp = compose(tiles, p2)
            ts = p2
            bitmap = bmp
            version.incrementAndGet()
            return count
        }
    }
}
