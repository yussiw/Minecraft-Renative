package com.voxelgame

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.sin
import kotlin.math.sqrt

/** Atlas de texturas 100% gerado por codigo (nenhum asset externo). */
object Atlas {
    const val TILES = 8
    const val TS = 16
    val bitmap: Bitmap by lazy { build() }

    private fun r(x: Int, y: Int, s: Int): Float = (Noise.hash(x, y, s * 7919 + 13) and 0xFFFF) / 65535f

    private fun col(rr: Int, gg: Int, bb: Int, v: Float): Int {
        val f = 1f + v
        return Color.rgb(
            (rr * f).toInt().coerceIn(0, 255),
            (gg * f).toInt().coerceIn(0, 255),
            (bb * f).toInt().coerceIn(0, 255)
        )
    }

    private fun build(): Bitmap {
        val size = TILES * TS
        val pix = IntArray(size * size)
        fun put(tile: Int, x: Int, y: Int, c: Int) {
            pix[((tile / TILES) * TS + y) * size + (tile % TILES) * TS + x] = c
        }
        for (y in 0 until TS) {
            for (x in 0 until TS) {
                // 0 grama (topo)
                put(0, x, y, col(95, 165, 60, (r(x, y, 2) - 0.5f) * 0.35f))
                // 1 grama (lado)
                val fringe = 3 + (r(x, 0, 3) * 3f).toInt()
                put(1, x, y, if (y < fringe) col(95, 165, 60, (r(x, y, 4) - 0.5f) * 0.35f)
                else col(134, 96, 67, (r(x, y, 5) - 0.5f) * 0.3f))
                // 2 terra
                put(2, x, y, col(134, 96, 67, (r(x, y, 6) - 0.5f) * 0.3f))
                // 3 pedra
                put(3, x, y, col(125, 125, 125, (r(x, y, 7) - 0.5f) * 0.28f))
                // 4 areia
                put(4, x, y, col(219, 207, 150, (r(x, y, 8) - 0.5f) * 0.10f))
                // 5 tronco (lado)
                put(5, x, y, col(104, 82, 50, (r(x, 0, 9) - 0.5f) * 0.45f + (r(x, y, 10) - 0.5f) * 0.12f))
                // 6 tronco (topo)
                val dd = sqrt((x - 7.5f) * (x - 7.5f) + (y - 7.5f) * (y - 7.5f))
                val edge = x == 0 || y == 0 || x == TS - 1 || y == TS - 1
                put(6, x, y, if (edge) col(104, 82, 50, (r(x, y, 11) - 0.5f) * 0.2f)
                else col(176, 140, 84, sin(dd * 1.7f) * 0.10f + (r(x, y, 12) - 0.5f) * 0.06f))
                // 7 folhas
                put(7, x, y, if (r(x, y, 13) > 0.82f) col(28, 80, 22, 0f)
                else col(54, 124, 38, (r(x, y, 14) - 0.5f) * 0.45f))
                // 8 tabuas
                val joint = ((y / 4) % 2) * 8
                val dark = (y % 4 == 3) || x == joint
                put(8, x, y, col(164, 131, 79, (if (dark) -0.22f else 0f) + (r(x, y, 15) - 0.5f) * 0.10f))
                // 9 pedregulho
                val cell = Noise.hash(x / 4, y / 4, 99)
                val shade = ((cell and 0xFF) / 255f - 0.5f) * 0.35f
                val e2 = (x % 4 == 0) || (y % 4 == 0)
                put(9, x, y, col(118, 118, 118, shade + (if (e2) -0.22f else 0f) + (r(x, y, 16) - 0.5f) * 0.08f))
            }
        }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pix, 0, size, 0, 0, size, size)
        return bmp
    }
}
