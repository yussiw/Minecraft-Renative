package com.voxelgame

import java.nio.ByteBuffer
import java.nio.ByteOrder

class MeshData(
    val cx: Int, val cz: Int, val ver: Int,
    val buf: ByteBuffer?, val quads: Int, val maxY: Int
)

/**
 * Gera a malha de um chunk: so faces visiveis, AO por vertice, 8 bytes por vertice.
 * Vertice = [x, y, z, brilho, tile, canto-de-textura, 0, 0]
 */
object Mesher {
    const val MAXQ = 16383

    private class Scratch {
        val padded = ByteArray(18 * 18 * H)
        val verts = ByteArray(MAXQ * 4 * 8)
    }

    private val tl = object : ThreadLocal<Scratch>() {
        override fun initialValue(): Scratch = Scratch()
    }

    // 0:+X 1:-X 2:+Y 3:-Y 4:+Z 5:-Z
    private val FNX = intArrayOf(1, -1, 0, 0, 0, 0)
    private val FNY = intArrayOf(0, 0, 1, -1, 0, 0)
    private val FNZ = intArrayOf(0, 0, 0, 0, 1, -1)
    private val FUX = intArrayOf(0, 0, 0, 1, 1, 0)
    private val FUY = intArrayOf(1, 0, 0, 0, 0, 1)
    private val FUZ = intArrayOf(0, 1, 1, 0, 0, 0)
    private val FVX = intArrayOf(0, 0, 1, 0, 0, 1)
    private val FVY = intArrayOf(0, 1, 0, 0, 1, 0)
    private val FVZ = intArrayOf(1, 0, 0, 1, 0, 0)
    private val BX = intArrayOf(1, 0, 0, 0, 0, 0)
    private val BY = intArrayOf(0, 0, 1, 0, 0, 0)
    private val BZ = intArrayOf(0, 0, 0, 0, 1, 0)
    private val SWAP = booleanArrayOf(true, false, false, false, false, true)
    private val FS = floatArrayOf(0.75f, 0.75f, 1.0f, 0.55f, 0.88f, 0.88f)
    private val AOB = floatArrayOf(0.45f, 0.65f, 0.82f, 1.0f)

    private fun solid(pad: ByteArray, px: Int, y: Int, pz: Int): Int {
        if (y < 0) return 1
        if (y >= H) return 0
        return if (pad[(px * 18 + pz) * H + y].toInt() != 0) 1 else 0
    }

    fun build(w: World, cx: Int, cz: Int, ver: Int): MeshData {
        val s = tl.get()!!
        val pad = s.padded
        val out = s.verts

        val ch = arrayOfNulls<Chunk>(9)
        for (dz in -1..1) for (dx in -1..1) ch[(dz + 1) * 3 + (dx + 1)] = w.chunk(cx + dx, cz + dz)

        for (px in 0 until 18) {
            val lx = px - 1
            val ncx = if (lx < 0) 0 else if (lx > 15) 2 else 1
            val nlx = lx and 15
            for (pz in 0 until 18) {
                val lz = pz - 1
                val ncz = if (lz < 0) 0 else if (lz > 15) 2 else 1
                val nlz = lz and 15
                System.arraycopy(ch[ncz * 3 + ncx]!!.blocks, (nlx * 16 + nlz) * H, pad, (px * 18 + pz) * H, H)
            }
        }

        var o = 0
        var quads = 0
        var maxY = 0
        val ao = IntArray(4)

        outer@ for (x in 0 until 16) {
            for (z in 0 until 16) {
                val col = ((x + 1) * 18 + (z + 1)) * H
                for (y in 0 until H) {
                    val b = pad[col + y].toInt()
                    if (b == 0) continue
                    for (f in 0 until 6) {
                        val nx = FNX[f]
                        val ny = FNY[f]
                        val nz = FNZ[f]
                        val yy = y + ny
                        val nb = if (yy < 0) 1 else if (yy >= H) 0 else pad[col + nx * 18 * H + nz * H + yy].toInt()
                        if (nb != 0) continue
                        if (quads >= MAXQ) break@outer

                        val ux = FUX[f]; val uy = FUY[f]; val uz = FUZ[f]
                        val vx = FVX[f]; val vy = FVY[f]; val vz = FVZ[f]
                        val bx = x + 1 + nx
                        val by = y + ny
                        val bz = z + 1 + nz
                        for (c in 0 until 4) {
                            val su = if (c == 1 || c == 2) 1 else -1
                            val sv = if (c >= 2) 1 else -1
                            val s1 = solid(pad, bx + su * ux, by + su * uy, bz + su * uz)
                            val s2 = solid(pad, bx + sv * vx, by + sv * vy, bz + sv * vz)
                            val cr = solid(pad, bx + su * ux + sv * vx, by + su * uy + sv * vy, bz + su * uz + sv * vz)
                            ao[c] = if (s1 == 1 && s2 == 1) 0 else 3 - (s1 + s2 + cr)
                        }

                        val tile = when (f) {
                            2 -> Blocks.top[b]
                            3 -> Blocks.bottom[b]
                            else -> Blocks.side[b]
                        }
                        val start = if (ao[0] + ao[2] >= ao[1] + ao[3]) 0 else 1
                        for (k in 0 until 4) {
                            val c = (start + k) and 3
                            val cu = if (c == 1 || c == 2) 1 else 0
                            val cv = if (c >= 2) 1 else 0
                            var tu = cu
                            var tv = cv
                            if (SWAP[f]) { tu = cv; tv = cu }
                            out[o] = (x + BX[f] + cu * ux + cv * vx).toByte()
                            out[o + 1] = (y + BY[f] + cu * uy + cv * vy).toByte()
                            out[o + 2] = (z + BZ[f] + cu * uz + cv * vz).toByte()
                            out[o + 3] = (FS[f] * AOB[ao[c]] * 255f).toInt().toByte()
                            out[o + 4] = tile.toByte()
                            out[o + 5] = (tu or (tv shl 1)).toByte()
                            out[o + 6] = 0
                            out[o + 7] = 0
                            o += 8
                        }
                        quads++
                        if (y + 1 > maxY) maxY = y + 1
                    }
                }
            }
        }

        // chunk sem faces: malha vazia (buffer nao nulo, para marcar o chunk como carregado)
        if (quads == 0) return MeshData(cx, cz, ver, ByteBuffer.allocateDirect(0), 0, 0)
        val buf = ByteBuffer.allocateDirect(o).order(ByteOrder.nativeOrder())
        buf.put(out, 0, o)
        buf.flip()
        return MeshData(cx, cz, ver, buf, quads, maxY)
    }
}
