package com.voxelgame

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class GameRenderer(private val game: Game, private val refreshRate: Float) : GLSurfaceView.Renderer {

    private class GLMesh(
        val cx: Int, val cz: Int, val vao: Int, val vbo: Int, val quads: Int, val maxY: Int, val ver: Int,
        val vao2: Int, val vbo2: Int, val quads2: Int
    )
    private class Job(val prio: Int, val body: () -> Unit) : Runnable {
        override fun run() = body()
    }

    private val meshes = HashMap<Long, GLMesh>()
    private val inFlight = HashSet<Long>()
    private val results = ConcurrentLinkedQueue<MeshData>()
    private val verCounter = AtomicInteger(0)

    private val workers = max(2, min(4, Runtime.getRuntime().availableProcessors() - 1))
    private val pool = ThreadPoolExecutor(
        workers, workers, 0L, TimeUnit.MILLISECONDS,
        PriorityBlockingQueue<Runnable>(128, Comparator<Runnable> { a, b -> (a as Job).prio.compareTo((b as Job).prio) }),
        ThreadFactory { r -> Thread(r, "mesher").apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1 } }
    )

    @Volatile private var wantCx = 0
    @Volatile private var wantCz = 0
    @Volatile private var wantR = 6

    // distancia de render adaptativa
    private val minR = 3
    private val maxR = 14
    private var radius = 6
    private var cap = maxR
    private var justGrew = false
    private var goodWindows = 0
    private var warmup = 3

    private var lastCx = Int.MIN_VALUE
    private var lastCz = Int.MIN_VALUE
    private var lastRadius = -1
    private var frameCount = 0
    private var lastNs = 0L
    private var accNs = 0L
    private var frames = 0
    private var width = 1
    private var height = 1

    private var prog = 0
    private var uMvp = 0
    private var uOrigin = 0
    private var uFog = 0
    private var uSky = 0
    private var uTex = 0
    private var uLight = 0
    private var lineProg = 0
    private var lMvp = 0
    private var lOff = 0
    private var lineVao = 0
    private var ibo = 0
    private var tex = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private val planes = FloatArray(24)

    private val skyR = 0.53f
    private val skyG = 0.76f
    private val skyB = 1.0f

    init {
        Stats.radius = radius
        wantR = radius
    }

    // ---------------------------------------------------------------- GL setup

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(p, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: " + GLES30.glGetProgramInfoLog(p))
        return p
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VS, FS)
        uMvp = GLES30.glGetUniformLocation(prog, "u_mvp")
        uOrigin = GLES30.glGetUniformLocation(prog, "u_origin")
        uFog = GLES30.glGetUniformLocation(prog, "u_fog")
        uSky = GLES30.glGetUniformLocation(prog, "u_sky")
        uTex = GLES30.glGetUniformLocation(prog, "u_tex")
        uLight = GLES30.glGetUniformLocation(prog, "u_light")
        lineProg = link(LVS, LFS)
        lMvp = GLES30.glGetUniformLocation(lineProg, "u_mvp")
        lOff = GLES30.glGetUniformLocation(lineProg, "u_off")

        // textura (atlas gerado por codigo)
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        tex = t[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST_MIPMAP_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        uploadAtlas()

        // indice compartilhado por todos os chunks (quads -> 2 triangulos)
        val idx = ShortArray(Mesher.MAXQ * 6)
        for (q in 0 until Mesher.MAXQ) {
            val b = q * 4
            idx[q * 6] = b.toShort()
            idx[q * 6 + 1] = (b + 1).toShort()
            idx[q * 6 + 2] = (b + 2).toShort()
            idx[q * 6 + 3] = b.toShort()
            idx[q * 6 + 4] = (b + 2).toShort()
            idx[q * 6 + 5] = (b + 3).toShort()
        }
        val ib = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder())
        ib.asShortBuffer().put(idx)
        val ids = IntArray(1)
        GLES30.glGenBuffers(1, ids, 0)
        ibo = ids[0]
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)

        // contorno do bloco mirado
        val e = 0.003f
        val lo = -e
        val hi = 1f + e
        val c = floatArrayOf(
            lo, lo, lo, hi, lo, lo, hi, lo, lo, hi, lo, hi, hi, lo, hi, lo, lo, hi, lo, lo, hi, lo, lo, lo,
            lo, hi, lo, hi, hi, lo, hi, hi, lo, hi, hi, hi, hi, hi, hi, lo, hi, hi, lo, hi, hi, lo, hi, lo,
            lo, lo, lo, lo, hi, lo, hi, lo, lo, hi, hi, lo, hi, lo, hi, hi, hi, hi, lo, lo, hi, lo, hi, hi
        )
        val lb = ByteBuffer.allocateDirect(c.size * 4).order(ByteOrder.nativeOrder())
        lb.asFloatBuffer().put(c)
        val lv = IntArray(2)
        GLES30.glGenVertexArrays(1, lv, 0)
        GLES30.glGenBuffers(1, lv, 1)
        lineVao = lv[0]
        GLES30.glBindVertexArray(lineVao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, lv[1])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, c.size * 4, lb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glBindVertexArray(0)

        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glClearColor(skyR, skyG, skyB, 1f)

        // contexto novo: os handles antigos nao valem mais
        meshes.clear()
        lastCx = Int.MIN_VALUE
        lastNs = 0L
    }

    private var texVersion = -1

    /** Sobe o atlas para a GPU (com mipmaps: tiles alinhados em potencia de 2, sem sangrar entre vizinhos). */
    private fun uploadAtlas() {
        val v = Atlas.version.get()
        val bmp = Atlas.bitmap
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        texVersion = v
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = max(1, w)
        height = max(1, h)
        GLES30.glViewport(0, 0, width, height)
    }

    // ---------------------------------------------------------------- chunks

    private fun wanted(cx: Int, cz: Int): Boolean {
        val dx = cx - wantCx
        val dz = cz - wantCz
        val r = wantR + 1
        return dx * dx + dz * dz <= r * r
    }

    private fun submit(cx: Int, cz: Int, prio: Int, force: Boolean) {
        val ver = verCounter.incrementAndGet()
        pool.execute(Job(prio) {
            try {
                if (!force && !wanted(cx, cz)) results.add(MeshData(cx, cz, ver, null, 0, 0))
                else results.add(Mesher.build(game.world, cx, cz, ver))
            } catch (t: Throwable) {
                Log.e("Blocos", "mesh falhou", t)
                results.add(MeshData(cx, cz, ver, null, 0, 0))
            }
        })
    }

    private fun scan(pcx: Int, pcz: Int) {
        val r = radius
        for (dz in -r..r) {
            for (dx in -r..r) {
                val d2 = dx * dx + dz * dz
                if (d2 > r * r) continue
                val cx = pcx + dx
                val cz = pcz + dz
                val k = chunkKey(cx, cz)
                if (meshes.containsKey(k) || inFlight.contains(k)) continue
                inFlight.add(k)
                submit(cx, cz, d2, false)
            }
        }
    }

    private fun makeVao(buf: ByteBuffer): IntArray {
        val ids = IntArray(2)
        GLES30.glGenVertexArrays(1, ids, 0)
        GLES30.glGenBuffers(1, ids, 1)
        GLES30.glBindVertexArray(ids[0])
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, ids[1])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, buf.remaining(), buf, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribIPointer(0, 4, GLES30.GL_UNSIGNED_BYTE, 8, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribIPointer(1, 2, GLES30.GL_UNSIGNED_BYTE, 8, 4)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBindVertexArray(0)
        return ids
    }

    private fun upload(r: MeshData) {
        val buf = r.buf ?: return
        val key = chunkKey(r.cx, r.cz)
        val old = meshes[key]
        if (old != null && old.ver > r.ver) return
        var vao = 0
        var vbo = 0
        var vao2 = 0
        var vbo2 = 0
        if (r.quads > 0) {
            val ids = makeVao(buf)
            vao = ids[0]; vbo = ids[1]
        }
        val buf2 = r.buf2
        if (r.quads2 > 0 && buf2 != null) {
            val ids = makeVao(buf2)
            vao2 = ids[0]; vbo2 = ids[1]
        }
        if (old != null) free(old)
        meshes[key] = GLMesh(r.cx, r.cz, vao, vbo, r.quads, r.maxY, r.ver, vao2, vbo2, r.quads2)
    }

    private fun free(m: GLMesh) {
        if (m.vao != 0) {
            GLES30.glDeleteVertexArrays(1, intArrayOf(m.vao), 0)
            GLES30.glDeleteBuffers(1, intArrayOf(m.vbo), 0)
        }
        if (m.vao2 != 0) {
            GLES30.glDeleteVertexArrays(1, intArrayOf(m.vao2), 0)
            GLES30.glDeleteBuffers(1, intArrayOf(m.vbo2), 0)
        }
    }

    private fun housekeep(pcx: Int, pcz: Int) {
        val r2 = (radius + 2) * (radius + 2)
        val it = meshes.entries.iterator()
        while (it.hasNext()) {
            val m = it.next().value
            val dx = m.cx - pcx
            val dz = m.cz - pcz
            if (dx * dx + dz * dz > r2) {
                free(m)
                it.remove()
            }
        }
        val w2 = (radius + 4) * (radius + 4)
        for (c in game.world.chunks.values) {
            if (c.edited) continue
            val dx = c.cx - pcx
            val dz = c.cz - pcz
            if (dx * dx + dz * dz > w2) game.world.chunks.remove(chunkKey(c.cx, c.cz))
        }
    }

    // ---------------------------------------------------------------- adaptacao

    private fun adapt(fps: Float) {
        if (warmup > 0) { warmup--; return }
        if (fps < 58f && radius > minR) {
            if (justGrew) cap = radius - 1
            radius--
            justGrew = false
            goodWindows = 0
        } else if (fps >= refreshRate * 0.96f) {
            justGrew = false
            goodWindows++
            if (goodWindows >= 4 && radius < min(cap, maxR)) {
                radius++
                goodWindows = 0
                justGrew = true
            }
        } else {
            goodWindows = 0
        }
        Stats.radius = radius
    }

    // ---------------------------------------------------------------- ceu

    private val sky = FloatArray(4) // r, g, b, luz

    private fun computeSky(t: Float, under: Boolean) {
        val sun = sin(t * 6.2831855f)
        var d = (sun + 0.15f) / 0.4f
        d = if (d < 0f) 0f else if (d > 1f) 1f else d
        d = d * d * (3f - 2f * d)
        var r = 0.02f + 0.51f * d
        var g = 0.03f + 0.73f * d
        var b = 0.09f + 0.91f * d
        val dusk = max(0f, 1f - Math.abs(sun) * 5f) * 0.6f
        r += (1.0f - r) * dusk
        g += (0.5f - g) * dusk
        b += (0.25f - b) * dusk
        if (under) {
            val k = 0.35f + 0.65f * d
            r = 0.06f * k; g = 0.22f * k; b = 0.42f * k
        }
        sky[0] = r; sky[1] = g; sky[2] = b
        sky[3] = 0.30f + 0.70f * d
    }

    // ---------------------------------------------------------------- frustum

    private fun extractPlanes(m: FloatArray) {
        for (i in 0 until 6) {
            val sign = if (i % 2 == 0) 1f else -1f
            val row = i / 2
            for (j in 0 until 4) planes[i * 4 + j] = m[j * 4 + 3] + sign * m[j * 4 + row]
        }
    }

    private fun visible(minx: Float, miny: Float, minz: Float, maxx: Float, maxy: Float, maxz: Float): Boolean {
        for (i in 0 until 6) {
            val a = planes[i * 4]
            val b = planes[i * 4 + 1]
            val c = planes[i * 4 + 2]
            val d = planes[i * 4 + 3]
            val x = if (a > 0f) maxx else minx
            val y = if (b > 0f) maxy else miny
            val z = if (c > 0f) maxz else minz
            if (a * x + b * y + c * z + d < 0f) return false
        }
        return true
    }

    // ---------------------------------------------------------------- frame

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        if (lastNs == 0L) lastNs = now
        val rawNs = now - lastNs
        lastNs = now
        var dt = rawNs / 1e9f
        if (dt > 0.05f) dt = 0.05f

        game.update(dt)
        if (Atlas.version.get() != texVersion) uploadAtlas()

        val pcx = floor(game.px / 16.0).toInt()
        val pcz = floor(game.pz / 16.0).toInt()
        wantCx = pcx
        wantCz = pcz
        wantR = radius
        if (pcx != lastCx || pcz != lastCz || radius != lastRadius) {
            scan(pcx, pcz)
            lastCx = pcx
            lastCz = pcz
            lastRadius = radius
        }

        // remeshes causados por quebrar/colocar blocos (prioridade maxima)
        while (true) {
            val k = game.world.remeshQueue.poll() ?: break
            if (meshes.containsKey(k)) submit(keyX(k), keyZ(k), -1, true)
        }

        // sobe para a GPU algumas malhas por frame (evita travadas)
        var budget = if (meshes.size < 24) 8 else 2
        while (budget > 0) {
            val r = results.poll() ?: break
            val key = chunkKey(r.cx, r.cz)
            inFlight.remove(key)
            if (r.buf == null) continue
            val dx = r.cx - pcx
            val dz = r.cz - pcz
            val lim = (radius + 2) * (radius + 2)
            if (dx * dx + dz * dz > lim) continue
            upload(r)
            budget--
        }

        frameCount++
        if (frameCount % 45 == 0) housekeep(pcx, pcz)

        // camera relativa (sem perda de precisao em coordenadas grandes)
        val yaw = game.yaw
        val pitch = game.pitch
        val dx = (-sin(yaw) * cos(pitch)).toFloat()
        val dy = sin(pitch).toFloat()
        val dz = (-cos(yaw) * cos(pitch)).toFloat()
        Matrix.perspectiveM(proj, 0, 70f, width.toFloat() / height, 0.1f, radius * 16f + 48f)
        Matrix.setLookAtM(view, 0, 0f, 0f, 0f, dx, dy, dz, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        extractPlanes(mvp)

        computeSky(game.time, game.underwater)
        GLES30.glClearColor(sky[0], sky[1], sky[2], 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        val fogEnd = radius * 16f - 6f
        if (game.underwater) GLES30.glUniform2f(uFog, 1f, 26f)
        else GLES30.glUniform2f(uFog, fogEnd * 0.55f, fogEnd)
        GLES30.glUniform3f(uSky, sky[0], sky[1], sky[2])
        GLES30.glUniform1f(uLight, sky[3])
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLES30.glUniform1i(uTex, 0)

        val ex = game.px
        val ey = game.py + Game.EYE
        val ez = game.pz
        var drawn = 0
        var quadsDrawn = 0
        for (m in meshes.values) {
            if (m.quads == 0) continue
            val ox = (m.cx * 16 - ex).toFloat()
            val oy = (-ey).toFloat()
            val oz = (m.cz * 16 - ez).toFloat()
            if (!visible(ox, oy, oz, ox + 16f, oy + m.maxY, oz + 16f)) continue
            GLES30.glUniform3f(uOrigin, ox, oy, oz)
            GLES30.glBindVertexArray(m.vao)
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, m.quads * 6, GLES30.GL_UNSIGNED_SHORT, 0)
            drawn++
            quadsDrawn += m.quads
        }

        if (game.hitValid) {
            GLES30.glUseProgram(lineProg)
            GLES30.glUniformMatrix4fv(lMvp, 1, false, mvp, 0)
            GLES30.glUniform3f(lOff, (game.hx - ex).toFloat(), (game.hy - ey).toFloat(), (game.hz - ez).toFloat())
            GLES30.glBindVertexArray(lineVao)
            GLES30.glDrawArrays(GLES30.GL_LINES, 0, 24)
        }
        GLES30.glBindVertexArray(0)

        // passe transparente: agua e vidro
        GLES30.glUseProgram(prog)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        for (m in meshes.values) {
            if (m.quads2 == 0) continue
            val ox = (m.cx * 16 - ex).toFloat()
            val oy = (-ey).toFloat()
            val oz = (m.cz * 16 - ez).toFloat()
            if (!visible(ox, oy, oz, ox + 16f, oy + m.maxY, oz + 16f)) continue
            GLES30.glUniform3f(uOrigin, ox, oy, oz)
            GLES30.glBindVertexArray(m.vao2)
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, m.quads2 * 6, GLES30.GL_UNSIGNED_SHORT, 0)
            quadsDrawn += m.quads2
        }
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glBindVertexArray(0)

        Stats.chunks = drawn
        Stats.quads = quadsDrawn

        frames++
        accNs += rawNs
        if (accNs >= 1_000_000_000L) {
            val fps = frames * 1e9f / accNs
            Stats.fps = fps
            adapt(fps)
            frames = 0
            accNs = 0
        }
    }

    companion object {
        private const val VS = """#version 300 es
layout(location = 0) in uvec4 a_pos;
layout(location = 1) in uvec2 a_tex;
uniform mat4 u_mvp;
uniform vec3 u_origin;
uniform vec2 u_fog;
out vec2 v_uv;
out float v_shade;
out float v_fog;
void main() {
    vec3 p = vec3(a_pos.xyz) + u_origin;
    gl_Position = u_mvp * vec4(p, 1.0);
    uint tile = a_tex.x;
    uint tc = a_tex.y;
    float tu = float(tc & 1u);
    float tv = float((tc >> 1u) & 1u);
    float col = float(tile & 7u);
    float row = float(tile >> 3u);
    const float e = 0.02;
    v_uv = vec2(col + mix(e, 1.0 - e, tu), row + mix(e, 1.0 - e, 1.0 - tv)) / 8.0;
    v_shade = float(a_pos.w) / 255.0;
    v_fog = clamp((length(p) - u_fog.x) / (u_fog.y - u_fog.x), 0.0, 1.0);
}
"""
        private const val FS = """#version 300 es
precision highp float;
in vec2 v_uv;
in float v_shade;
in float v_fog;
uniform sampler2D u_tex;
uniform vec3 u_sky;
uniform float u_light;
out vec4 o_color;
void main() {
    vec4 t = texture(u_tex, v_uv);
    if (t.a < 0.1) discard;
    vec3 rgb = t.rgb / t.a;
    vec3 c = rgb * v_shade * u_light;
    o_color = vec4(mix(c, u_sky, v_fog), t.a);
}
"""
        private const val LVS = """#version 300 es
layout(location = 0) in vec3 a_pos;
uniform mat4 u_mvp;
uniform vec3 u_off;
void main() {
    gl_Position = u_mvp * vec4(a_pos + u_off, 1.0);
}
"""
        private const val LFS = """#version 300 es
precision mediump float;
out vec4 o_color;
void main() {
    o_color = vec4(0.0, 0.0, 0.0, 1.0);
}
"""
    }
}
