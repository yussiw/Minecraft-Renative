package com.voxelgame

import kotlin.math.min

object Stats {
    @Volatile var fps = 0f
    @Volatile var radius = 0
    @Volatile var chunks = 0
    @Volatile var quads = 0
    @Volatile var x = 0
    @Volatile var y = 0
    @Volatile var z = 0
    @Volatile var fx = 0.0
    @Volatile var fy = 0.0
    @Volatile var fz = 0.0
    @Volatile var yaw = 0.0
    @Volatile var pitch = 0.0
    @Volatile var clock = "06:00"
    @Volatile var day = 0
    @Volatile var facing = ""
    @Volatile var underwater = false
    @Volatile var flying = false
    @Volatile var sprinting = false
    @Volatile var sneaking = false
    @Volatile var creative = false
    @Volatile var dead = false
    @Volatile var health = 20f
    @Volatile var food = 20
    @Volatile var air = 10
    @Volatile var flash = 0f
    @Volatile var debug = false
}

/** Pilha de itens: 36 slots (0..8 = hotbar), como no Minecraft Java. */
class Inventory {
    val id = IntArray(36)
    val count = IntArray(36)

    /** Devolve quantos itens nao couberam. */
    fun add(item: Int, n: Int): Int {
        var left = n
        for (i in 0 until 36) {
            if (left > 0 && id[i] == item && count[i] in 1..63) {
                val m = min(64 - count[i], left)
                count[i] += m
                left -= m
            }
        }
        for (i in 0 until 36) {
            if (left > 0 && count[i] == 0) {
                id[i] = item
                val m = min(64, left)
                count[i] = m
                left -= m
            }
        }
        return left
    }

    fun take(slot: Int, n: Int) {
        count[slot] -= n
        if (count[slot] <= 0) { count[slot] = 0; id[slot] = 0 }
    }

    fun set(slot: Int, item: Int, n: Int) {
        id[slot] = if (n > 0) item else 0
        count[slot] = n
    }
}

class Input {
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var stickFlick = false
    @Volatile var jump = false
    @Volatile var sneak = false
    @Volatile var sprint = false
    @Volatile var down = false
    @Volatile var attack = false
    @Volatile var useHeld = false
    @Volatile var useReq = false
    @Volatile var dropReq = false
    @Volatile var pickReq = false
    @Volatile var flyToggle = false
    @Volatile var modeToggle = false
    @Volatile var respawnReq = false
    @Volatile var shotReq = false
    @Volatile var paused = false
    @Volatile var hideHud = false
    @Volatile var hotbarDelta = 0
    @Volatile var selected = 0

    val inv = Inventory()

    private val lock = Any()
    private var lx = 0f
    private var ly = 0f

    fun addLook(dx: Float, dy: Float) {
        synchronized(lock) { lx += dx; ly += dy }
    }

    fun takeLook(out: FloatArray) {
        synchronized(lock) { out[0] = lx; out[1] = ly; lx = 0f; ly = 0f }
    }
}

object Blocks {
    // blocos: 1 grama, 2 terra, 3 pedra, 4 areia, 5 tronco, 6 folhas, 7 tabuas, 8 pedregulho,
    //         9 neve, 10 cascalho, 11 vidro, 12 agua, 13 tijolos, 14 grama alta, 15 dente-de-leao, 16 margarida
    // itens (>= 100): 100 maca
    const val GLASS = 11
    const val WATER = 12
    const val APPLE = 100
    const val MAX_BLOCK = 16

    val top = intArrayOf(0, 0, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18)
    val side = intArrayOf(0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18)
    val bottom = intArrayOf(0, 2, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18)
    val names = arrayOf(
        "Ar", "Bloco de grama", "Terra", "Pedra", "Areia", "Tronco de carvalho", "Folhas de carvalho",
        "Tábuas de carvalho", "Pedregulho", "Neve", "Cascalho", "Vidro", "Água", "Tijolos",
        "Grama alta", "Dente-de-leão", "Margarida"
    )

    /** Blocos que aparecem no inventario criativo. */
    val creativeItems = intArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 100)

    fun isPlant(id: Int) = id in 14..16
    fun isItem(id: Int) = id >= 100
    fun isCube(id: Int) = id in 1..13

    fun name(id: Int): String = when {
        id == APPLE -> "Maçã"
        id in 1..MAX_BLOCK -> names[id]
        else -> ""
    }

    fun iconTile(id: Int): Int = when {
        id == APPLE -> 15
        id == 1 -> 1
        id == 5 -> 5
        id in 1..MAX_BLOCK -> top[id]
        else -> 0
    }

    /** Segundos para quebrar com a mao (dureza do wiki x 1,5). */
    fun hardness(id: Int): Float = when (id) {
        1 -> 0.6f
        2 -> 0.5f
        3 -> 1.5f
        4 -> 0.5f
        5 -> 2.0f
        6 -> 0.2f
        7 -> 2.0f
        8 -> 2.0f
        9 -> 0.2f
        10 -> 0.6f
        11 -> 0.3f
        13 -> 2.0f
        14, 15, 16 -> 0f
        else -> 1f
    }

    fun drop(id: Int, r: Float): Int = when (id) {
        1 -> 2
        3 -> 8
        6 -> if (r < 0.025f) APPLE else 0
        11, 14 -> 0
        else -> id
    }

    fun foodValue(id: Int): Int = if (id == APPLE) 4 else 0
    fun foodSat(id: Int): Float = if (id == APPLE) 2.4f else 0f
}
