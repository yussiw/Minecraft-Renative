package com.voxelgame

object Stats {
    @Volatile var fps = 0f
    @Volatile var radius = 0
    @Volatile var chunks = 0
    @Volatile var quads = 0
    @Volatile var x = 0
    @Volatile var y = 0
    @Volatile var z = 0
    @Volatile var clock = "06:00"
    @Volatile var underwater = false
    @Volatile var flying = false
}

class Input {
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var jump = false
    @Volatile var down = false
    @Volatile var flyToggle = false
    @Volatile var selected = 0
    @Volatile var breakReq = false
    @Volatile var placeReq = false

    /** Bloco de cada slot da hotbar (editavel pelo inventario). */
    val hotbar = intArrayOf(1, 2, 3, 4, 5, 6, 7, 8)

    private val lock = Any()
    private var lx = 0f
    private var ly = 0f

    fun addLook(dx: Float, dy: Float) {
        synchronized(lock) { lx += dx; ly += dy }
    }

    fun takeLook(out: FloatArray) {
        synchronized(lock) { out[0] = lx; out[1] = ly; lx = 0f; ly = 0f }
    }
}

object Blocks {
    // ids: 1 grama, 2 terra, 3 pedra, 4 areia, 5 tronco, 6 folhas, 7 tabuas, 8 pedregulho,
    //      9 neve, 10 cascalho, 11 vidro, 12 agua, 13 tijolos
    const val GLASS = 11
    const val WATER = 12
    const val MAX_ID = 13

    val top = intArrayOf(0, 0, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14)
    val side = intArrayOf(0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14)
    val bottom = intArrayOf(0, 2, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14)
    val iconTile = intArrayOf(0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14)
    val names = arrayOf(
        "Ar", "Grama", "Terra", "Pedra", "Areia", "Tronco", "Folhas", "Tabuas",
        "Pedregulho", "Neve", "Cascalho", "Vidro", "Agua", "Tijolos"
    )

    /** Blocos que o jogador pode escolher no inventario. */
    val placeable = intArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13)
}
