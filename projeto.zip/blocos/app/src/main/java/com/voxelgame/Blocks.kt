package com.voxelgame

object Stats {
    @Volatile var fps = 0f
    @Volatile var radius = 0
    @Volatile var chunks = 0
    @Volatile var quads = 0
}

class Input {
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var jump = false
    @Volatile var selected = 0
    @Volatile var breakReq = false
    @Volatile var placeReq = false

    private val lock = Any()
    private var lx = 0f
    private var ly = 0f

    fun addLook(dx: Float, dy: Float) {
        synchronized(lock) { lx += dx; ly += dy }
    }

    fun takeLook(out: FloatArray) {
        synchronized(lock) { out[0] = lx; out[1] = ly; lx = 0f; ly = 0f }
    }
}

object Blocks {
    // ids: 1 grama, 2 terra, 3 pedra, 4 areia, 5 tronco, 6 folhas, 7 tabuas, 8 pedregulho
    val top = intArrayOf(0, 0, 2, 3, 4, 6, 7, 8, 9)
    val side = intArrayOf(0, 1, 2, 3, 4, 5, 7, 8, 9)
    val bottom = intArrayOf(0, 2, 2, 3, 4, 6, 7, 8, 9)
    val iconTile = intArrayOf(0, 1, 2, 3, 4, 5, 7, 8, 9)
    val hotbar = intArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
}
