package com.voxelgame

import android.app.Activity
import android.content.Intent
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val refresh = pickHighRefresh()

        // reaplica o resource pack escolhido da ultima vez
        try {
            val saved = File(filesDir, "pack.zip")
            if (saved.exists()) Atlas.loadPack(saved.absolutePath)
        } catch (t: Throwable) {
            // pack corrompido: segue com as texturas geradas
        }

        val input = Input()
        val world = World()
        val game = Game(world, input)
        val renderer = GameRenderer(game, refresh)

        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 0, 24, 0)
            preserveEGLContextOnPause = true
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        val root = FrameLayout(this)
        root.addView(gl)
        root.addView(HudView(this, input) { pickPack() })
        setContentView(root)
        hideSystemUi()
    }

    private fun pickPack() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(i, REQ_PACK)
        } catch (t: Throwable) {
            Toast.makeText(this, "Nao consegui abrir o seletor de arquivos", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PACK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val msg = try {
                val tmp = File(filesDir, "pack_new.zip")
                contentResolver.openInputStream(uri)!!.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                val n = Atlas.loadPack(tmp.absolutePath)
                if (n > 0) {
                    tmp.copyTo(File(filesDir, "pack.zip"), true)
                    tmp.delete()
                    "Pack carregado: $n de ${Atlas.COUNT} texturas"
                } else {
                    tmp.delete()
                    "Esse arquivo nao tem texturas no formato do Minecraft"
                }
            } catch (t: Throwable) {
                "Nao consegui ler esse arquivo (precisa ser um .zip de resource pack)"
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    companion object {
        private const val REQ_PACK = 7
    }

    /** Pede ao sistema o maior refresh rate disponivel (90/120 Hz), na mesma resolucao. */
    private fun pickHighRefresh(): Float {
        return try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            var best = d.mode
            for (m in d.supportedModes) {
                if (m.physicalWidth == best.physicalWidth && m.physicalHeight == best.physicalHeight &&
                    m.refreshRate > best.refreshRate
                ) best = m
            }
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
            best.refreshRate
        } catch (t: Throwable) {
            60f
        }
    }

    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onResume() {
        super.onResume()
        gl.onResume()
        hideSystemUi()
    }

    override fun onPause() {
        gl.onPause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }
}
