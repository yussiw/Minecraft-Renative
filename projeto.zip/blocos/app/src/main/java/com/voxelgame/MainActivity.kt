package com.voxelgame

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Environment
import android.os.Looper
import android.os.Process
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), HudHost {
    private lateinit var gl: GLSurfaceView
    private lateinit var hud: HudView
    private lateinit var input: Input
    private lateinit var world: World
    private lateinit var game: Game
    private lateinit var saveFile: File
    private val handler = Handler(Looper.getMainLooper())
    private val autosave = object : Runnable {
        override fun run() {
            Thread { Save.save(saveFile, world, game, input) }.start()
            handler.postDelayed(this, 45_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // captura qualquer crash e salva num .txt legivel por qualquer gerenciador de arquivos,
        // sem precisar de PC/adb. Fica em Android/data/<pacote>/files/crash_log.txt
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                val f = File(getExternalFilesDir(null), "crash_log.txt")
                f.writeText(
                    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()) +
                        "\n" + android.util.Log.getStackTraceString(e)
                )
            } catch (t: Throwable) { }
            Process.killProcess(Process.myPid())
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val refresh = pickHighRefresh()

        // mods primeiro (registram blocos e tiles), depois o resource pack (que pode retexturizar tudo)
        try { ModManager.loadAll(filesDir) } catch (t: Throwable) { }
        try {
            val saved = File(filesDir, "pack.zip")
            if (saved.exists()) Atlas.loadPack(saved.absolutePath) else Atlas.rebuild()
        } catch (t: Throwable) {
            // pack corrompido: segue com as texturas geradas
            try { Atlas.rebuild() } catch (t2: Throwable) { }
        }

        Controls.load(this)
        input = Input()
        world = World()
        saveFile = File(filesDir, "world.dat")
        val saved = Save.load(saveFile, world)
        game = Game(world, input)
        if (saved != null) game.restore(saved)
        val renderer = GameRenderer(game, refresh) { bmp -> saveShot(bmp) }

        gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 0, 24, 0)
            preserveEGLContextOnPause = true
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        val root = FrameLayout(this)
        root.addView(gl)
        hud = HudView(this, input, this)
        root.addView(hud)
        setContentView(root)
        hideSystemUi()
    }

    override fun saveExit() {
        Save.save(saveFile, world, game, input)
        finish()
    }

    override fun onBackPressed() {
        hud.back()
    }

    private fun saveShot(bmp: Bitmap) {
        Thread {
            val ok = try {
                val name = "blocos_" + SimpleDateFormat("yyyy-MM-dd_HH.mm.ss", Locale.US).format(Date()) + ".png"
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Blocos")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
                    File(dir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
                true
            } catch (t: Throwable) {
                false
            }
            runOnUiThread {
                Toast.makeText(this, if (ok) "Captura de tela salva" else "Falha ao salvar a captura", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    override fun pickPack() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(i, REQ_PACK)
        } catch (t: Throwable) {
            Toast.makeText(this, "Nao consegui abrir o seletor de arquivos", Toast.LENGTH_LONG).show()
        }
    }

    override fun pickMod() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        try {
            startActivityForResult(i, REQ_MOD)
        } catch (t: Throwable) {
            Toast.makeText(this, "Nao consegui abrir o seletor de arquivos", Toast.LENGTH_LONG).show()
        }
    }

    override fun clearMods() {
        Thread {
            ModManager.clear(filesDir)
            runOnUiThread {
                Toast.makeText(this, "Mods removidos. Reiniciando...", Toast.LENGTH_SHORT).show()
                recreate()
            }
        }.start()
    }

    private fun displayName(uri: android.net.Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ix >= 0) name = c.getString(ix)
                }
            }
        } catch (t: Throwable) { }
        var n = (name ?: uri.lastPathSegment ?: "mod").replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!n.endsWith(".jar") && !n.endsWith(".zip")) n += ".jar"
        return n
    }

    private fun addMods(data: Intent) {
        val uris = ArrayList<android.net.Uri>()
        val clip = data.clipData
        if (clip != null) for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        else data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        Thread {
            var ok = 0
            val dir = ModManager.dir(filesDir)
            dir.mkdirs()
            for (u in uris) {
                try {
                    val f = File(dir, displayName(u))
                    contentResolver.openInputStream(u)!!.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                    java.util.zip.ZipFile(f).use { } // so aceita jar/zip valido
                    ok++
                } catch (t: Throwable) {
                    try { File(dir, displayName(u)).delete() } catch (t2: Throwable) { }
                }
            }
            runOnUiThread {
                if (ok > 0) {
                    Toast.makeText(this, "$ok mod(s) adicionado(s). Reiniciando...", Toast.LENGTH_SHORT).show()
                    recreate()
                } else {
                    Toast.makeText(this, "Esse arquivo nao e um .jar de mod valido", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MOD && resultCode == RESULT_OK && data != null) { addMods(data); return }
        if (requestCode != REQ_PACK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val msg = try {
                val tmp = File(filesDir, "pack_new.zip")
                contentResolver.openInputStream(uri)!!.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
                val info = Atlas.loadPack(tmp.absolutePath)
                if (info.total > 0) {
                    tmp.copyTo(File(filesDir, "pack.zip"), true)
                    tmp.delete()
                    "Pack carregado: ${info.blocks} texturas, ${info.hud} sprites do HUD" +
                        (if (info.mods > 0) ", ${info.mods} de mods" else "")
                } else {
                    tmp.delete()
                    "Esse arquivo nao tem texturas no formato do Minecraft"
                }
            } catch (t: Throwable) {
                "Nao consegui ler esse arquivo (precisa ser um .zip de resource pack)"
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    companion object {
        private const val REQ_PACK = 7
        private const val REQ_MOD = 8
    }

    /** Pede ao sistema o maior refresh rate disponivel (90/120 Hz), na mesma resolucao. */
    private fun pickHighRefresh(): Float {
        return try {
            @Suppress("DEPRECATION")
            val d = windowManager.defaultDisplay
            var best = d.mode
            for (m in d.supportedModes) {
                if (m.physicalWidth == best.physicalWidth && m.physicalHeight == best.physicalHeight &&
                    m.refreshRate > best.refreshRate
                ) best = m
            }
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
            best.refreshRate
        } catch (t: Throwable) {
            60f
        }
    }

    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onResume() {
        super.onResume()
        gl.onResume()
        hideSystemUi()
        handler.postDelayed(autosave, 45_000L)
    }

    override fun onPause() {
        handler.removeCallbacks(autosave)
        hud.pauseIfPlaying()
        gl.onPause()
        Save.save(saveFile, world, game, input)
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }
}
